# FF Diamond: Free Fire top-up storefront

Full-stack store for selling Free Fire diamonds in Bangladeshi Taka, paid by bKash, Nagad or Rocket and
**verified manually by an administrator**. Orders live in a database, customers track them by Order ID, and
the owner runs everything from `/admin`.

No npm dependencies. Needs **Node 22.13+** (uses the built-in SQLite).

## Run it

```bash
cp .env.example .env        # optional: edit PORT, SITE_URL, ADMIN_PASSWORD ...
npm start
```

On first start an admin account is created. If `ADMIN_PASSWORD` is empty a random password is printed **once**
in the console. Open `http://localhost:3000/admin`, sign in, then:

1. **Payment methods**: enter your own bKash / Nagad / Rocket numbers. A method stays hidden from customers
   (and orders for it are refused) until it is enabled **and** has a number.
2. **Packages**: adjust prices, availability and order.
3. **Settings**: support contact and footer disclaimer. Change the admin password.

Reset a forgotten admin password: `ADMIN_PASSWORD='a-long-passphrase' npm run set-admin`

Tests: `npm test` (23 API checks against a throwaway database).

## Pages

| URL | What |
|---|---|
| `/` | Hero with 3D card, packages with quantity selectors, Buy Now confirmation modal, how-it-works, FAQ |
| `/pay?pkg=ID&qty=N` | Payment page: method cards, merchant number + Copy, instructions, UID/TrxID form |
| `/track`, `/track/FF-XXXXXXXX` | Order status: progress stepper, history, auto-refresh while open |
| `/admin` | Orders (filter, search, status, public note, history), packages, payment methods, settings |

## How payment verification works (and what it does not do)

- The site **never** marks anything as paid. Every order starts as `Pending`. Only a signed-in admin can move it
  to Under Review / Verified / Completed / Rejected, and each change is logged.
- The admin panel shows the Transaction ID, amount and UID **for you to match against your own wallet
  statement**. This is manual verification. There is no automatic bKash/Nagad/Rocket API check, because that
  needs a merchant agreement with each provider. If you get one, add a server-side webhook/verify step that
  moves orders to `verified`; the status model already supports it.
- A Transaction ID can be used once per provider. Duplicates are rejected.
- The site has no PIN / OTP / password / card fields anywhere.

## Security notes

- Prices and totals are computed on the server from the package table. Anything the browser sends about price
  or status is ignored. Order rows snapshot the price at purchase time.
- Admin passwords: scrypt hashes. Sessions: random token in an `HttpOnly; SameSite=Strict` cookie (`Secure` on
  HTTPS), stored hashed, with a per-session CSRF token and an Origin check on every write.
- Login lockout after 8 failed attempts per IP per 15 minutes; order creation limited per IP per hour
  (`ORDER_RATE_LIMIT`, default 10); order lookups limited per minute. Limits are in-memory (single process).
- Strict CSP (`script-src 'self'`, no inline script), HSTS on HTTPS, frame/sniff/referrer protections.
  The UI builds DOM with text nodes only, so customer-supplied text is never interpreted as HTML.
- No secrets in front-end code. `.env` and `data/` are git-ignored.
- Tracking pages show masked UID/TrxID; Order IDs are unguessable (8 chars from a 32-symbol alphabet).

## Deploying

Run it as a long-lived Node process with a **persistent disk** (a VPS, or Render / Railway / Fly with a
volume). It will **not** work on serverless platforms such as Vercel, because SQLite needs a writable
persistent file. Put it behind HTTPS (Caddy / nginx / Cloudflare) and set:

```
TRUST_PROXY=1
SITE_URL=https://your-domain
```

Back up `data/store.db` (it holds all orders). Remove `ADMIN_PASSWORD` from the environment after first boot.
To scale beyond one process, move the rate limiter to a shared store and the database to Postgres.

## Brand logos

No provider logos are bundled, because they are trademarks and should only be used with permission. Each
method shows its name as a coloured wordmark until you supply a logo you are allowed to use: put the file in
`public/img/` and enter `/img/bkash.svg` (or an `https://` URL) under Admin > Payment methods. The footer
states that the store is independent and not affiliated with Garena/Free Fire or the payment providers.

## Layout

```
server.js        HTTP server, API, sessions, static files
lib/             db (schema/seed), security (scrypt, limiter, cookies), validate (all server rules)
public/          pages, css, js (no build step)
views/           shared nav/footer/icon sprite, included server-side
scripts/         set-admin.js
tests/           smoke.js (API)
```

## Performance (low-end Android)

Transform/opacity-only animation, no blur on repeated elements, particle canvas capped (26 particles and 28fps
on weak devices), animation pauses when the tab or the card is off-screen, brotli/gzip static responses with
ETags, and `prefers-reduced-motion` turns motion off.
