'use strict';
// End-to-end API smoke test. Starts the real server on a throwaway DB and exercises the business rules.
//   npm test
const { spawn } = require('node:child_process');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const assert = require('node:assert/strict');

const PORT = 3900 + Math.floor(Math.random() * 90);
const BASE = `http://127.0.0.1:${PORT}`;
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ffstore-'));
const ADMIN_PW = 'correct-horse-battery-1';

let passed = 0;
const t = async (name, fn) => {
  try { await fn(); passed++; console.log('  ✓', name); }
  catch (e) { console.error('  ✗', name, '\n   ', e.message); process.exitCode = 1; throw e; }
};

async function call(method, url, { body, cookie, csrf, origin } = {}) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (cookie) headers.Cookie = cookie;
  if (csrf) headers['X-CSRF-Token'] = csrf;
  if (origin) headers.Origin = origin;
  const res = await fetch(BASE + url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  let json = null; try { json = await res.json(); } catch { /* not json */ }
  return { status: res.status, json, headers: res.headers };
}

(async () => {
  const child = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, PORT: String(PORT), HOST: '127.0.0.1', DB_PATH: path.join(tmp, 't.db'), ADMIN_PASSWORD: ADMIN_PW,
      ADMIN_USERNAME: 'boss', ORDER_RATE_LIMIT: '200', SITE_URL: '' },
    stdio: ['ignore', 'pipe', 'inherit'],
  });
  await new Promise((resolve, reject) => {
    child.stdout.on('data', (d) => { if (String(d).includes('listening')) resolve(); });
    child.on('exit', (c) => reject(new Error('server exited ' + c)));
    setTimeout(() => reject(new Error('server start timeout')), 8000);
  });

  try {
    console.log('Public catalogue');
    await t('config lists the 7 default packages with server-side prices', async () => {
      const r = await call('GET', '/api/config');
      assert.equal(r.status, 200);
      assert.equal(r.json.packages.length, 7);
      assert.deepEqual([r.json.packages[0].diamonds, r.json.packages[0].price], [500, 280]);
      assert.deepEqual([r.json.packages[6].diamonds, r.json.packages[6].price], [50000, 9990]);
      assert.ok(r.headers.get('content-security-policy').includes("script-src 'self'"));
    });
    await t('payment numbers start empty (admin must supply them) and are hidden', async () => {
      const r = await call('GET', '/api/payment-methods');
      assert.equal(r.json.methods.length, 3);
      for (const m of r.json.methods) { assert.equal(m.available, false); assert.equal(m.number, ''); }
    });
    await t('orders are refused while a method has no admin-supplied number', async () => {
      const r = await call('POST', '/api/orders', { body: { packageId: 1, quantity: 1, playerUid: '123456789', paymentMethod: 'bkash', trxId: 'AB12CD34EF' } });
      assert.equal(r.status, 409); assert.equal(r.json.error.code, 'method_unavailable');
    });

    console.log('Admin auth');
    let cookie; let csrf;
    await t('admin endpoints require a session', async () => {
      assert.equal((await call('GET', '/api/admin/orders')).status, 401);
      assert.equal((await call('PATCH', '/api/admin/packages/1', { body: { price: 1 } })).status, 401);
    });
    await t('wrong password is rejected with a generic message', async () => {
      const r = await call('POST', '/api/admin/login', { body: { username: 'boss', password: 'nope-nope-nope' } });
      assert.equal(r.status, 401);
      const r2 = await call('POST', '/api/admin/login', { body: { username: 'ghost', password: 'nope-nope-nope' } });
      assert.equal(r.json.error.message, r2.json.error.message);
    });
    await t('login sets an HttpOnly SameSite=Strict cookie and returns a CSRF token', async () => {
      const r = await call('POST', '/api/admin/login', { body: { username: 'boss', password: ADMIN_PW } });
      assert.equal(r.status, 200);
      const sc = r.headers.getSetCookie()[0];
      assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Strict/);
      cookie = sc.split(';')[0]; csrf = r.json.csrf;
      assert.ok(csrf.length > 10);
    });
    await t('state-changing admin calls need the CSRF token and a same-site origin', async () => {
      assert.equal((await call('PATCH', '/api/admin/payment-methods/bkash', { cookie, body: { number: '01712345678' } })).status, 403);
      assert.equal((await call('PATCH', '/api/admin/payment-methods/bkash', { cookie, csrf, origin: 'https://evil.example', body: { number: '01712345678' } })).status, 403);
    });

    console.log('Admin configuration');
    await t('payment numbers are validated and normalised', async () => {
      const bad = await call('PATCH', '/api/admin/payment-methods/bkash', { cookie, csrf, body: { number: '12345' } });
      assert.equal(bad.status, 422);
      const good = await call('PATCH', '/api/admin/payment-methods/bkash', { cookie, csrf, body: { number: '+880 1712-345678' } });
      assert.equal(good.json.method.number, '01712345678');
      await call('PATCH', '/api/admin/payment-methods/nagad', { cookie, csrf, body: { number: '01812345678' } });
      await call('PATCH', '/api/admin/payment-methods/rocket', { cookie, csrf, body: { number: '017123456789' } });
      const pub = await call('GET', '/api/payment-methods');
      assert.ok(pub.json.methods.every((m) => m.available && m.number));
    });

    console.log('Ordering');
    let order;
    await t('server-side validation rejects bad input with field messages', async () => {
      const base = { packageId: 1, quantity: 1, playerUid: '123456789', paymentMethod: 'bkash', trxId: 'AB12CD34EF' };
      const cases = [
        [{ playerUid: '12ab' }, 'playerUid'], [{ playerUid: '' }, 'playerUid'],
        [{ trxId: 'short' }, 'trxId'], [{ trxId: 'AB12-CD34EF' }, 'trxId'],
        [{ quantity: 0 }, 'quantity'], [{ quantity: 21 }, 'quantity'], [{ quantity: 1.5 }, 'quantity'],
        [{ paymentMethod: 'paypal' }, 'paymentMethod'], [{ packageId: 'x' }, 'packageId'],
      ];
      for (const [patch, field] of cases) {
        const r = await call('POST', '/api/orders', { body: { ...base, ...patch } });
        assert.equal(r.status, 422, JSON.stringify(patch));
        assert.ok(r.json.error.fields[field], `${field} message for ${JSON.stringify(patch)}`);
      }
    });
    await t('a valid order is created as PENDING, never as paid', async () => {
      const r = await call('POST', '/api/orders', { body: { packageId: 1, quantity: 2, playerUid: '123456789', paymentMethod: 'bkash', trxId: 'ab12cd34ef', clientToken: 'token-aaaaaaaaaaaaaaaa' } });
      assert.equal(r.status, 201);
      order = r.json.order;
      assert.match(order.id, /^FF-[2-9A-HJ-NP-Z]{8}$/);
      assert.equal(order.status, 'pending');
      assert.equal(order.totalDiamonds, 1000); assert.equal(order.totalPrice, 560);
      assert.equal(order.trxId, 'AB••••••EF');
      assert.equal(order.playerUid, '••••••789');
    });
    await t('client-supplied prices/totals/status are ignored', async () => {
      const r = await call('POST', '/api/orders', { body: { packageId: 3, quantity: 1, playerUid: '987654321', paymentMethod: 'nagad', trxId: 'ZZ99YY88XX', price: 1, totalPrice: 1, status: 'completed' } });
      assert.equal(r.status, 201);
      assert.equal(r.json.order.totalPrice, 750); assert.equal(r.json.order.status, 'pending');
    });
    await t('a Transaction ID can only be used once (case/space-insensitive)', async () => {
      const r = await call('POST', '/api/orders', { body: { packageId: 2, quantity: 1, playerUid: '555555555', paymentMethod: 'bkash', trxId: 'ab12 cd34ef' } });
      assert.equal(r.status, 409); assert.equal(r.json.error.code, 'duplicate_trx');
      // same TrxID on a different provider is a different transaction
      const r2 = await call('POST', '/api/orders', { body: { packageId: 2, quantity: 1, playerUid: '555555555', paymentMethod: 'rocket', trxId: 'AB12CD34EF' } });
      assert.equal(r2.status, 201);
    });
    await t('re-sending the same submission returns the original order (idempotent)', async () => {
      const r = await call('POST', '/api/orders', { body: { packageId: 1, quantity: 2, playerUid: '123456789', paymentMethod: 'bkash', trxId: 'AB12CD34EF', clientToken: 'token-aaaaaaaaaaaaaaaa' } });
      assert.equal(r.status, 201); assert.equal(r.json.order.id, order.id);
    });

    console.log('Tracking');
    await t('order can be tracked by ID; private data stays masked', async () => {
      const r = await call('GET', `/api/orders/${order.id.toLowerCase()}`);
      assert.equal(r.status, 200); assert.equal(r.json.order.id, order.id);
      assert.equal(r.json.order.timeline.length, 1);
      assert.ok(!JSON.stringify(r.json).includes('123456789'));
    });
    await t('unknown or malformed IDs return the same 404', async () => {
      const a = await call('GET', '/api/orders/FF-AAAAAAAA'); const b = await call('GET', '/api/orders/nonsense');
      assert.equal(a.status, 404); assert.equal(b.status, 404); assert.equal(a.json.error.message, b.json.error.message);
    });

    console.log('Admin order handling');
    await t('admin can verify an order with a customer-visible note; timeline updates', async () => {
      const r = await call('PATCH', `/api/admin/orders/${order.id}`, { cookie, csrf, body: { status: 'under_review', note: 'Checking your payment' } });
      assert.equal(r.status, 200);
      await call('PATCH', `/api/admin/orders/${order.id}`, { cookie, csrf, body: { status: 'verified', note: '' } });
      const pub = await call('GET', `/api/orders/${order.id}`);
      assert.equal(pub.json.order.status, 'verified');
      assert.deepEqual(pub.json.order.timeline.map((e) => e.status), ['pending', 'under_review', 'verified']);
      assert.equal((await call('PATCH', `/api/admin/orders/${order.id}`, { cookie, csrf, body: { status: 'paid!' } })).status, 422);
    });
    await t('admin list supports status filter and search by TrxID / UID', async () => {
      const all = await call('GET', '/api/admin/orders', { cookie });
      assert.equal(all.json.total, 3); assert.equal(all.json.counts.verified, 1); assert.equal(all.json.counts.pending, 2);
      assert.equal((await call('GET', '/api/admin/orders?status=verified', { cookie })).json.orders.length, 1);
      assert.equal((await call('GET', '/api/admin/orders?q=zz99', { cookie })).json.orders.length, 1);
      assert.equal((await call('GET', '/api/admin/orders?q=%25', { cookie })).json.orders.length, 0); // wildcard is escaped
    });
    await t('price edits apply to new orders only; old orders keep their snapshot', async () => {
      assert.equal((await call('PATCH', '/api/admin/packages/1', { cookie, csrf, body: { price: 300 } })).status, 200);
      const n = await call('POST', '/api/orders', { body: { packageId: 1, quantity: 1, playerUid: '111111111', paymentMethod: 'nagad', trxId: 'NEWTRX0001' } });
      assert.equal(n.json.order.totalPrice, 300);
      const old = await call('GET', `/api/orders/${order.id}`);
      assert.equal(old.json.order.totalPrice, 560);
    });
    await t('unavailable packages cannot be ordered; packages with orders cannot be deleted', async () => {
      await call('PATCH', '/api/admin/packages/4', { cookie, csrf, body: { available: false } });
      const r = await call('POST', '/api/orders', { body: { packageId: 4, quantity: 1, playerUid: '222222222', paymentMethod: 'nagad', trxId: 'NEWTRX0002' } });
      assert.equal(r.status, 409);
      assert.equal((await call('DELETE', '/api/admin/packages/1', { cookie, csrf })).status, 409);
      const created = await call('POST', '/api/admin/packages', { cookie, csrf, body: { diamonds: 100, price: 90, sortOrder: 99 } });
      assert.equal(created.status, 201);
      assert.equal((await call('DELETE', `/api/admin/packages/${created.json.package.id}`, { cookie, csrf })).status, 200);
    });

    console.log('Static hosting & hardening');
    await t('private files and traversal attempts are not served', async () => {
      for (const p of ['/server.js', '/lib/db.js', '/.env', '/data/t.db', '/..%2f..%2fserver.js', '/%2e%2e/server.js', '/public/../server.js']) {
        const r = await fetch(BASE + p);
        assert.equal(r.status, 404, p);
      }
      assert.equal((await fetch(BASE + '//evil.example/x')).status, 400);
    });
    await t('admin/pay/track pages are noindex', async () => {
      for (const p of ['/admin', '/pay', '/track']) {
        const r = await fetch(BASE + p);
        if (r.status === 200) assert.match(r.headers.get('x-robots-tag') || '', /noindex/);
      }
    });
    await t('changing the admin password signs other sessions out', async () => {
      const second = await call('POST', '/api/admin/login', { body: { username: 'boss', password: ADMIN_PW } });
      const cookie2 = second.headers.getSetCookie()[0].split(';')[0];
      const r = await call('POST', '/api/admin/password', { cookie, csrf, body: { currentPassword: ADMIN_PW, newPassword: 'brand-new-passphrase-2' } });
      assert.equal(r.status, 200);
      assert.equal((await call('GET', '/api/admin/me', { cookie: cookie2 })).status, 401);
      assert.equal((await call('GET', '/api/admin/me', { cookie })).status, 200);
    });
    await t('repeated bad logins are rate limited', async () => {
      let last;
      for (let i = 0; i < 10; i++) last = await call('POST', '/api/admin/login', { body: { username: 'boss', password: 'wrong-wrong-wrong' } });
      assert.equal(last.status, 429);
      assert.ok(last.headers.get('retry-after'));
    });

    console.log(`\nAll ${passed} checks passed.`);
  } finally {
    child.kill('SIGTERM');
    fs.rmSync(tmp, { recursive: true, force: true });
  }
})().catch(() => { process.exitCode = 1; setTimeout(() => process.exit(1), 100); });
