'use strict';
/**
 * FF Diamond Store: zero-dependency Node server (Node >= 22.13, built-in SQLite).
 *
 * Security model in one paragraph:
 *  - Prices are NEVER taken from the browser. The server looks up the package and
 *    computes every total itself.
 *  - A Transaction ID never marks anything as paid. Orders always start as "pending"
 *    and only an authenticated admin can move them forward.
 *  - Admin credentials live only in the database (scrypt hash) and in a first-boot
 *    env var / console message. Sessions are random tokens in HttpOnly SameSite=Strict
 *    cookies, stored hashed, with a per-session CSRF token.
 *  - The site never asks for, and has no field for, PINs, OTPs, passwords or card data.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const crypto = require('node:crypto');

require('./lib/env').load(path.join(__dirname, '.env'));

const { openDb, tx, nowIso } = require('./lib/db');
const sec = require('./lib/security');
const v = require('./lib/validate');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const DB_PATH = path.resolve(__dirname, process.env.DB_PATH || './data/store.db');
const SITE_URL = (process.env.SITE_URL || '').replace(/\/+$/, '');
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const SESSION_MS = Math.max(1, Number(process.env.SESSION_HOURS || 8)) * 3_600_000;
const ORDER_RATE_LIMIT = Math.max(1, Number(process.env.ORDER_RATE_LIMIT || 10)); // orders per IP per hour
const COOKIE = 'ff_admin';
const PUBLIC_DIR = path.join(__dirname, 'public');
const VIEWS_DIR = path.join(__dirname, 'views');

class HttpError extends Error {
  constructor(status, code, message, fields, headers) {
    super(message);
    this.status = status; this.code = code; this.fields = fields; this.headers = headers;
  }
}
const tooMany = (retryAfter, msg = 'Too many requests.') => {
  const mins = Math.max(1, Math.ceil(retryAfter / 60));
  return new HttpError(429, 'rate_limited', `${msg} Please try again in about ${mins} minute${mins > 1 ? 's' : ''}.`,
    undefined, { 'Retry-After': String(retryAfter) });
};

/* ------------------------------------------------------------------ helpers */

const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' https://fonts.googleapis.com",
  'font-src https://fonts.gstatic.com',
  "img-src 'self' data: https:",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');

function isHttps(req) {
  if (req.socket.encrypted) return true;
  if (TRUST_PROXY) {
    const h = String(req.headers['x-forwarded-proto'] || '').split(',').pop().trim();
    return h === 'https';
  }
  return false;
}

function clientIp(req) {
  if (TRUST_PROXY) {
    const xff = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean);
    if (xff.length) return xff[xff.length - 1]; // the hop our own proxy appended
  }
  return req.socket.remoteAddress || 'unknown';
}

function requestHost(req) {
  const h = TRUST_PROXY && req.headers['x-forwarded-host']
    ? String(req.headers['x-forwarded-host']).split(',')[0].trim()
    : req.headers.host;
  return h || '';
}

function setSecurityHeaders(req, res) {
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  if (isHttps(req)) res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
}

function sendJson(res, status, body, headers = {}) {
  const buf = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': buf.length,
    'Cache-Control': 'no-store',
    'X-Robots-Tag': 'noindex',
    ...headers,
  });
  res.end(buf);
}

function readJson(req, limit = 32 * 1024) {
  return new Promise((resolve, reject) => {
    const ct = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    if (ct !== 'application/json') return reject(new HttpError(415, 'unsupported_media_type', 'Requests must be JSON.'));
    let size = 0; let tooBig = false; const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { tooBig = true; return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (tooBig) return reject(new HttpError(413, 'too_large', 'Request is too large.', undefined, { Connection: 'close' }));
      try {
        const obj = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}');
        if (obj === null || typeof obj !== 'object' || Array.isArray(obj)) throw new Error('shape');
        resolve(obj);
      } catch { reject(new HttpError(400, 'bad_json', 'Invalid request body.')); }
    });
    req.on('error', reject);
  });
}

const mask = (s, head, tail) => (s.length <= head + tail
  ? '•'.repeat(s.length)
  : s.slice(0, head) + '•'.repeat(s.length - head - tail) + s.slice(s.length - tail));

const escapeAttr = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ------------------------------------------------------------- static files */

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
};
const PAGES = { '/': 'index.html', '/pay': 'pay.html', '/track': 'track.html', '/admin': 'admin.html' };
const NOINDEX_PAGES = new Set(['pay.html', 'track.html', 'admin.html']);
const PARTIALS = ['sprite', 'nav', 'footer'];
const fileCache = new Map();

function renderHtml(html) {
  return html
    .replace(/<!--include:([\w-]+)-->/g, (_, name) => {
      try { return fs.readFileSync(path.join(VIEWS_DIR, `${name}.html`), 'utf8'); } catch { return ''; }
    })
    .replaceAll('{{SITE_URL}}', escapeAttr(SITE_URL));
}

function loadFile(rel) {
  const full = path.join(PUBLIC_DIR, rel);
  if (full !== PUBLIC_DIR && !full.startsWith(PUBLIC_DIR + path.sep)) return null;
  let st;
  try { st = fs.statSync(full); } catch { return null; }
  if (!st.isFile()) return null;
  const ext = path.extname(full).toLowerCase();
  const type = MIME[ext];
  if (!type) return null;

  let sig = String(st.mtimeMs);
  if (ext === '.html') {
    for (const p of PARTIALS) {
      try { sig += ':' + fs.statSync(path.join(VIEWS_DIR, `${p}.html`)).mtimeMs; } catch { /* optional */ }
    }
  }
  const hit = fileCache.get(full);
  if (hit && hit.sig === sig) return hit;

  let buf = fs.readFileSync(full);
  if (ext === '.html') buf = Buffer.from(renderHtml(buf.toString('utf8')));
  const compressible = /^(text\/|application\/json|image\/svg)/.test(type) && buf.length > 800;
  const entry = {
    sig, type, raw: buf,
    br: compressible ? zlib.brotliCompressSync(buf, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 5 } }) : null,
    gz: compressible ? zlib.gzipSync(buf, { level: 6 }) : null,
    etag: `W/"${crypto.createHash('sha1').update(buf).digest('base64url').slice(0, 20)}"`,
    ext,
  };
  fileCache.set(full, entry);
  return entry;
}

function sendFile(req, res, entry, { cache, noindex, status = 200 } = {}) {
  const ae = String(req.headers['accept-encoding'] || '');
  let body = entry.raw; let enc = null;
  if (entry.br && /\bbr\b/.test(ae)) { body = entry.br; enc = 'br'; }
  else if (entry.gz && /\bgzip\b/.test(ae)) { body = entry.gz; enc = 'gzip'; }
  const headers = {
    'Content-Type': entry.type,
    'Cache-Control': cache || 'no-cache',
    ETag: entry.etag,
    Vary: 'Accept-Encoding',
  };
  if (enc) headers['Content-Encoding'] = enc;
  if (noindex) headers['X-Robots-Tag'] = 'noindex, nofollow';
  if (status === 200 && req.headers['if-none-match'] === entry.etag) {
    res.writeHead(304, headers); res.end(); return;
  }
  headers['Content-Length'] = body.length;
  res.writeHead(status, headers);
  res.end(req.method === 'HEAD' ? undefined : body);
}

function serveNotFound(req, res) {
  const html = Buffer.from(renderHtml(
    '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<title>Page not found</title><link rel="stylesheet" href="/css/app.css"></head><body class="page-notfound">' +
    '<main class="wrap notfound"><h1>404</h1><p>This page doesn’t exist.</p><a class="btn btn-primary" href="/">Back to the store</a></main></body></html>'));
  res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': html.length, 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex' });
  res.end(req.method === 'HEAD' ? undefined : html);
}

function servePublic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD' }); res.end(); return;
  }
  let p = pathname;
  if (p.length > 1 && p.endsWith('/')) p = p.slice(0, -1);

  if (p === '/robots.txt') {
    const body = ['User-agent: *', 'Disallow: /admin', 'Disallow: /api/', 'Disallow: /pay', 'Disallow: /track', 'Allow: /',
      ...(SITE_URL ? [`Sitemap: ${SITE_URL}/sitemap.xml`] : [])].join('\n') + '\n';
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'public, max-age=3600' });
    return res.end(req.method === 'HEAD' ? undefined : body);
  }
  if (p === '/sitemap.xml') {
    if (!SITE_URL) return serveNotFound(req, res);
    const body = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${escapeAttr(SITE_URL)}/</loc></url></urlset>\n`;
    res.writeHead(200, { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'public, max-age=3600' });
    return res.end(req.method === 'HEAD' ? undefined : body);
  }

  let file = PAGES[p];
  if (!file && p.startsWith('/track/')) file = 'track.html';
  if (file) {
    const entry = loadFile(file);
    if (!entry) return serveNotFound(req, res);
    return sendFile(req, res, entry, { noindex: NOINDEX_PAGES.has(file) });
  }

  let rel;
  try { rel = decodeURIComponent(p).replace(/^\/+/, ''); } catch { return serveNotFound(req, res); }
  if (!rel || rel.includes('\0') || rel.split('/').some((seg) => seg === '..' || seg.startsWith('.')) || rel.endsWith('.html')) {
    return serveNotFound(req, res);
  }
  const entry = loadFile(rel);
  if (!entry) return serveNotFound(req, res);
  const longLived = entry.ext === '.woff2' || entry.ext === '.png' || entry.ext === '.jpg' || entry.ext === '.webp';
  return sendFile(req, res, entry, { cache: longLived ? 'public, max-age=86400' : 'public, max-age=300, must-revalidate' });
}

/* ---------------------------------------------------------------- the app */

function createApp(db, { dummyHash }) {
  const limiter = new sec.Limiter();

  const getSettings = () => Object.fromEntries(db.prepare('SELECT key, value FROM settings').all().map((r) => [r.key, r.value]));

  const toPackage = (p) => ({ id: p.id, diamonds: p.diamonds, price: p.price, available: !!p.available, sortOrder: p.sort_order });
  const toMethodAdmin = (m) => ({
    code: m.code, name: m.name, accountType: m.account_type, number: m.number,
    instructions: m.instructions, logoUrl: m.logo_url, enabled: !!m.enabled,
  });

  function publicOrder(o) {
    const events = db.prepare('SELECT to_status, note, created_at FROM order_events WHERE order_id = ? ORDER BY id').all(o.id);
    const method = db.prepare('SELECT name FROM payment_methods WHERE code = ?').get(o.payment_method);
    return {
      id: o.id, status: o.status, statusLabel: v.STATUS_LABELS[o.status],
      quantity: o.quantity, unitDiamonds: o.unit_diamonds, unitPrice: o.unit_price,
      totalDiamonds: o.total_diamonds, totalPrice: o.total_price,
      paymentMethod: method ? method.name : o.payment_method,
      playerUid: mask(o.player_uid, 0, 3), trxId: mask(o.trx_id, 2, 2),
      note: o.admin_note, createdAt: o.created_at, updatedAt: o.updated_at,
      timeline: events.map((e) => ({ status: e.to_status, statusLabel: v.STATUS_LABELS[e.to_status], note: e.note, at: e.created_at })),
    };
  }

  function adminOrder(o, withEvents = false) {
    const out = {
      id: o.id, status: o.status, statusLabel: v.STATUS_LABELS[o.status],
      quantity: o.quantity, unitDiamonds: o.unit_diamonds, unitPrice: o.unit_price,
      totalDiamonds: o.total_diamonds, totalPrice: o.total_price,
      playerUid: o.player_uid, paymentMethod: o.payment_method, trxId: o.trx_id,
      note: o.admin_note, createdAt: o.created_at, updatedAt: o.updated_at,
    };
    if (withEvents) {
      out.events = db.prepare('SELECT from_status, to_status, note, actor, created_at FROM order_events WHERE order_id = ? ORDER BY id')
        .all(o.id).map((e) => ({ from: e.from_status, to: e.to_status, note: e.note, actor: e.actor, at: e.created_at }));
    }
    return out;
  }

  /* ---- sessions ---- */
  function getSession(req) {
    const token = sec.parseCookies(req.headers.cookie)[COOKIE];
    if (!token || token.length > 100) return null;
    const row = db.prepare(
      'SELECT s.token_hash, s.csrf, s.expires_at, a.id AS admin_id, a.username ' +
      'FROM sessions s JOIN admins a ON a.id = s.admin_id WHERE s.token_hash = ?').get(sec.sha256(token));
    if (!row || row.expires_at <= Date.now()) return null;
    return row;
  }

  const sessionCookie = (req, value, maxAgeSec) =>
    sec.serializeCookie(COOKIE, value, { maxAge: maxAgeSec, secure: isHttps(req) });

  /* ---- routes ---- */
  const routes = [];
  const route = (method, pattern, handler, opts = {}) => {
    routes.push({ method, handler, admin: !!opts.admin, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$') });
  };

  /* Public: catalogue */
  route('GET', '/api/config', () => {
    const s = getSettings();
    const packages = db.prepare('SELECT * FROM packages ORDER BY sort_order, diamonds').all().map(toPackage);
    return { supportContact: s.support_contact || '', disclaimer: s.disclaimer || '', maxQty: v.MAX_QTY, packages };
  });

  route('GET', '/api/payment-methods', () => {
    const rows = db.prepare('SELECT * FROM payment_methods ORDER BY sort_order').all();
    return {
      methods: rows.map((m) => {
        const available = !!m.enabled && m.number !== '';
        return {
          code: m.code, name: m.name, accountType: m.account_type, logoUrl: m.logo_url,
          instructions: m.instructions, available,
          number: available ? m.number : '',   // only reveal numbers that customers may actually use
        };
      }),
    };
  });

  /* Public: place an order. Server computes everything; nothing here marks a payment as successful. */
  route('POST', '/api/orders', async (ctx) => {
    const rl = limiter.hit(`order:${ctx.ip}`, ORDER_RATE_LIMIT, 3_600_000);
    if (!rl.ok) throw tooMany(rl.retryAfter, 'You have placed several orders recently.');
    const body = await ctx.body();

    const fields = {};
    const q = v.quantity(body.quantity); if (!q.ok) fields.quantity = q.error;
    const pid = v.positiveInt(body.packageId, 'Package', 1_000_000); if (!pid.ok) fields.packageId = 'Choose a diamond package.';
    const u = v.uid(body.playerUid); if (!u.ok) fields.playerUid = u.error;
    const m = v.methodCode(body.paymentMethod); if (!m.ok) fields.paymentMethod = m.error;
    const t = v.trxId(body.trxId); if (!t.ok) fields.trxId = t.error;
    const tok = v.clientToken(body.clientToken); if (!tok.ok) fields.clientToken = tok.error;
    if (Object.keys(fields).length) throw new HttpError(422, 'validation', 'Please fix the highlighted fields.', fields);

    const order = tx(db, () => {
      if (tok.value) {
        const prior = db.prepare('SELECT * FROM orders WHERE client_token = ?').get(tok.value);
        if (prior) return prior; // same submission retried (e.g. flaky network): return the original order
      }
      const pkg = db.prepare('SELECT * FROM packages WHERE id = ?').get(pid.value);
      if (!pkg || !pkg.available) {
        throw new HttpError(409, 'package_unavailable', 'That package is not available right now. Please choose another.', { packageId: 'Package unavailable.' });
      }
      const pm = db.prepare('SELECT * FROM payment_methods WHERE code = ?').get(m.value);
      if (!pm || !pm.enabled || pm.number === '') {
        throw new HttpError(409, 'method_unavailable', `${pm ? pm.name : 'That method'} is not available right now. Please choose another payment method.`, { paymentMethod: 'Method unavailable.' });
      }
      const now = nowIso();
      for (let attempt = 0; attempt < 6; attempt++) {
        const id = sec.orderId();
        try {
          db.prepare(
            'INSERT INTO orders (id, client_token, package_id, unit_diamonds, unit_price, quantity, total_diamonds, total_price, ' +
            'player_uid, payment_method, trx_id, status, admin_note, created_at, updated_at) ' +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', '', ?, ?)")
            .run(id, tok.value, pkg.id, pkg.diamonds, pkg.price, q.value, pkg.diamonds * q.value, pkg.price * q.value,
              u.value, m.value, t.value, now, now);
          db.prepare("INSERT INTO order_events (order_id, from_status, to_status, note, actor, created_at) VALUES (?, NULL, 'pending', '', 'customer', ?)")
            .run(id, now);
          return db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
        } catch (e) {
          const msg = String(e && e.message);
          if (msg.includes('orders.id')) continue;
          if (msg.includes('trx_id')) {
            throw new HttpError(409, 'duplicate_trx',
              'This Transaction ID has already been submitted. If it was you, track your order; otherwise contact support.',
              { trxId: 'This Transaction ID has already been used.' });
          }
          throw e;
        }
      }
      throw new HttpError(500, 'id_collision', 'We could not create your order. Please try again.');
    });
    return { status: 201, body: { order: publicOrder(order) } };
  });

  /* Public: track an order by its unguessable ID */
  route('GET', '/api/orders/:id', (ctx) => {
    const rl = limiter.hit(`track:${ctx.ip}`, 60, 60_000);
    if (!rl.ok) throw tooMany(rl.retryAfter);
    const id = v.orderIdParam(ctx.params.id);
    if (!id.ok) throw new HttpError(404, 'not_found', 'We could not find that order. Check the Order ID and try again.');
    const o = db.prepare('SELECT * FROM orders WHERE id = ?').get(id.value);
    if (!o) throw new HttpError(404, 'not_found', 'We could not find that order. Check the Order ID and try again.');
    return { order: publicOrder(o) };
  });

  /* Admin: auth */
  route('POST', '/api/admin/login', async (ctx) => {
    const key = `login:${ctx.ip}`;
    const b = limiter.blocked(key, 8);
    if (b.blocked) throw tooMany(b.retryAfter, 'Too many failed sign-in attempts.');
    const body = await ctx.body();
    const username = typeof body.username === 'string' ? body.username.trim().slice(0, 64) : '';
    const password = typeof body.password === 'string' ? body.password.slice(0, 200) : '';
    const admin = username ? db.prepare('SELECT * FROM admins WHERE username = ?').get(username) : null;
    const good = await sec.verifyPassword(password, admin ? admin.password_hash : dummyHash);
    if (!admin || !good) {
      limiter.hit(key, 8, 15 * 60_000);
      throw new HttpError(401, 'bad_credentials', 'Incorrect username or password.');
    }
    limiter.clear(key);
    const token = sec.randomToken(32);
    const csrf = sec.randomToken(18);
    db.prepare('INSERT INTO sessions (token_hash, admin_id, csrf, expires_at, created_at) VALUES (?, ?, ?, ?, ?)')
      .run(sec.sha256(token), admin.id, csrf, Date.now() + SESSION_MS, Date.now());
    return { headers: { 'Set-Cookie': sessionCookie(ctx.req, token, SESSION_MS / 1000) }, body: { username: admin.username, csrf } };
  });

  route('POST', '/api/admin/logout', (ctx) => {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(ctx.session.token_hash);
    return { headers: { 'Set-Cookie': sessionCookie(ctx.req, '', 0) }, body: { ok: true } };
  }, { admin: true });

  route('GET', '/api/admin/me', (ctx) => ({ username: ctx.session.username, csrf: ctx.session.csrf }), { admin: true });

  route('POST', '/api/admin/password', async (ctx) => {
    const body = await ctx.body();
    const cur = typeof body.currentPassword === 'string' ? body.currentPassword : '';
    const next = typeof body.newPassword === 'string' ? body.newPassword : '';
    const admin = db.prepare('SELECT * FROM admins WHERE id = ?').get(ctx.session.admin_id);
    if (!(await sec.verifyPassword(cur, admin.password_hash))) {
      throw new HttpError(422, 'validation', 'Current password is incorrect.', { currentPassword: 'Incorrect password.' });
    }
    if (next.length < 12 || next.length > 200) {
      throw new HttpError(422, 'validation', 'New password must be at least 12 characters.', { newPassword: 'Use at least 12 characters.' });
    }
    if (next === cur) throw new HttpError(422, 'validation', 'Choose a different password.', { newPassword: 'Must differ from the current password.' });
    db.prepare('UPDATE admins SET password_hash = ? WHERE id = ?').run(await sec.hashPassword(next), admin.id);
    db.prepare('DELETE FROM sessions WHERE admin_id = ? AND token_hash != ?').run(admin.id, ctx.session.token_hash);
    return { ok: true };
  }, { admin: true });

  /* Admin: orders */
  route('GET', '/api/admin/orders', (ctx) => {
    const sp = ctx.url.searchParams;
    const where = []; const params = [];
    const st = sp.get('status');
    if (st) { if (!v.status(st).ok) throw new HttpError(400, 'bad_request', 'Invalid status filter.'); where.push('status = ?'); params.push(st); }
    const qRaw = (sp.get('q') || '').trim().slice(0, 40);
    if (qRaw) {
      const like = '%' + qRaw.toUpperCase().replace(/[\\%_]/g, (c) => '\\' + c) + '%';
      where.push("(id LIKE ? ESCAPE '\\' OR player_uid LIKE ? ESCAPE '\\' OR trx_id LIKE ? ESCAPE '\\')");
      params.push(like, like, like);
    }
    const limit = Math.min(100, Math.max(1, parseInt(sp.get('limit') || '30', 10) || 30));
    const offset = Math.max(0, parseInt(sp.get('offset') || '0', 10) || 0);
    const clause = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const rows = db.prepare(`SELECT * FROM orders ${clause} ORDER BY created_at DESC, id LIMIT ? OFFSET ?`).all(...params, limit, offset);
    const total = db.prepare(`SELECT COUNT(*) AS c FROM orders ${clause}`).get(...params).c;
    const counts = Object.fromEntries(v.STATUSES.map((s) => [s, 0]));
    for (const r of db.prepare('SELECT status, COUNT(*) AS c FROM orders GROUP BY status').all()) counts[r.status] = r.c;
    return { orders: rows.map((o) => adminOrder(o)), total, counts };
  }, { admin: true });

  route('GET', '/api/admin/orders/:id', (ctx) => {
    const id = v.orderIdParam(ctx.params.id);
    const o = id.ok && db.prepare('SELECT * FROM orders WHERE id = ?').get(id.value);
    if (!o) throw new HttpError(404, 'not_found', 'Order not found.');
    return { order: adminOrder(o, true) };
  }, { admin: true });

  route('PATCH', '/api/admin/orders/:id', async (ctx) => {
    const id = v.orderIdParam(ctx.params.id);
    const body = await ctx.body();
    const updated = tx(db, () => {
      const o = id.ok && db.prepare('SELECT * FROM orders WHERE id = ?').get(id.value);
      if (!o) throw new HttpError(404, 'not_found', 'Order not found.');
      const fields = {};
      let nextStatus = o.status; let nextNote = o.admin_note;
      if (body.status !== undefined) { const s = v.status(body.status); if (s.ok) nextStatus = s.value; else fields.status = s.error; }
      if (body.note !== undefined) { const n = v.text(body.note, 300, 'Note'); if (n.ok) nextNote = n.value; else fields.note = n.error; }
      if (Object.keys(fields).length) throw new HttpError(422, 'validation', 'Please fix the highlighted fields.', fields);
      if (nextStatus !== o.status || nextNote !== o.admin_note) {
        const now = nowIso();
        db.prepare('UPDATE orders SET status = ?, admin_note = ?, updated_at = ? WHERE id = ?').run(nextStatus, nextNote, now, o.id);
        db.prepare('INSERT INTO order_events (order_id, from_status, to_status, note, actor, created_at) VALUES (?, ?, ?, ?, ?, ?)')
          .run(o.id, o.status, nextStatus, nextNote, `admin:${ctx.session.username}`, now);
      }
      return db.prepare('SELECT * FROM orders WHERE id = ?').get(o.id);
    });
    return { order: adminOrder(updated, true) };
  }, { admin: true });

  /* Admin: packages */
  route('GET', '/api/admin/packages', () => ({
    packages: db.prepare('SELECT * FROM packages ORDER BY sort_order, diamonds').all().map(toPackage),
  }), { admin: true });

  route('POST', '/api/admin/packages', async (ctx) => {
    const body = await ctx.body();
    const fields = {};
    const d = v.positiveInt(body.diamonds, 'Diamonds'); if (!d.ok) fields.diamonds = d.error;
    const p = v.positiveInt(body.price, 'Price'); if (!p.ok) fields.price = p.error;
    const so = body.sortOrder === undefined ? v.ok(0) : v.sortOrder(body.sortOrder); if (!so.ok) fields.sortOrder = so.error;
    if (Object.keys(fields).length) throw new HttpError(422, 'validation', 'Please fix the highlighted fields.', fields);
    const available = body.available === false ? 0 : 1;
    const r = db.prepare('INSERT INTO packages (diamonds, price, available, sort_order, updated_at) VALUES (?, ?, ?, ?, ?)')
      .run(d.value, p.value, available, so.value, nowIso());
    return { status: 201, body: { package: toPackage(db.prepare('SELECT * FROM packages WHERE id = ?').get(Number(r.lastInsertRowid))) } };
  }, { admin: true });

  route('PATCH', '/api/admin/packages/:id', async (ctx) => {
    const id = Number(ctx.params.id);
    const cur = Number.isInteger(id) && db.prepare('SELECT * FROM packages WHERE id = ?').get(id);
    if (!cur) throw new HttpError(404, 'not_found', 'Package not found.');
    const body = await ctx.body();
    const fields = {};
    let { diamonds, price, available, sort_order: sortOrder } = cur;
    if (body.diamonds !== undefined) { const r = v.positiveInt(body.diamonds, 'Diamonds'); if (r.ok) diamonds = r.value; else fields.diamonds = r.error; }
    if (body.price !== undefined) { const r = v.positiveInt(body.price, 'Price'); if (r.ok) price = r.value; else fields.price = r.error; }
    if (body.sortOrder !== undefined) { const r = v.sortOrder(body.sortOrder); if (r.ok) sortOrder = r.value; else fields.sortOrder = r.error; }
    if (body.available !== undefined) { if (typeof body.available === 'boolean') available = body.available ? 1 : 0; else fields.available = 'Must be true or false.'; }
    if (Object.keys(fields).length) throw new HttpError(422, 'validation', 'Please fix the highlighted fields.', fields);
    db.prepare('UPDATE packages SET diamonds = ?, price = ?, available = ?, sort_order = ?, updated_at = ? WHERE id = ?')
      .run(diamonds, price, available, sortOrder, nowIso(), id);
    return { package: toPackage(db.prepare('SELECT * FROM packages WHERE id = ?').get(id)) };
  }, { admin: true });

  route('DELETE', '/api/admin/packages/:id', (ctx) => {
    const id = Number(ctx.params.id);
    if (!Number.isInteger(id) || !db.prepare('SELECT 1 FROM packages WHERE id = ?').get(id)) throw new HttpError(404, 'not_found', 'Package not found.');
    if (db.prepare('SELECT COUNT(*) AS c FROM orders WHERE package_id = ?').get(id).c > 0) {
      throw new HttpError(409, 'in_use', 'This package has orders, so it cannot be deleted. Mark it unavailable instead.');
    }
    db.prepare('DELETE FROM packages WHERE id = ?').run(id);
    return { ok: true };
  }, { admin: true });

  /* Admin: payment methods */
  route('GET', '/api/admin/payment-methods', () => ({
    methods: db.prepare('SELECT * FROM payment_methods ORDER BY sort_order').all().map(toMethodAdmin),
  }), { admin: true });

  route('PATCH', '/api/admin/payment-methods/:code', async (ctx) => {
    const code = v.methodCode(ctx.params.code);
    const cur = code.ok && db.prepare('SELECT * FROM payment_methods WHERE code = ?').get(code.value);
    if (!cur) throw new HttpError(404, 'not_found', 'Payment method not found.');
    const body = await ctx.body();
    const fields = {};
    let { number, instructions, enabled, account_type: accountType, logo_url: logo } = cur;
    if (body.number !== undefined) { const r = v.walletNumber(body.number); if (r.ok) number = r.value; else fields.number = r.error; }
    if (body.instructions !== undefined) { const r = v.text(body.instructions, 800, 'Instructions'); if (r.ok) instructions = r.value; else fields.instructions = r.error; }
    if (body.accountType !== undefined) { const r = v.accountType(body.accountType); if (r.ok) accountType = r.value; else fields.accountType = r.error; }
    if (body.logoUrl !== undefined) { const r = v.logoUrl(body.logoUrl); if (r.ok) logo = r.value; else fields.logoUrl = r.error; }
    if (body.enabled !== undefined) { if (typeof body.enabled === 'boolean') enabled = body.enabled ? 1 : 0; else fields.enabled = 'Must be true or false.'; }
    if (Object.keys(fields).length) throw new HttpError(422, 'validation', 'Please fix the highlighted fields.', fields);
    db.prepare('UPDATE payment_methods SET number = ?, instructions = ?, account_type = ?, logo_url = ?, enabled = ? WHERE code = ?')
      .run(number, instructions, accountType, logo, enabled, cur.code);
    return { method: toMethodAdmin(db.prepare('SELECT * FROM payment_methods WHERE code = ?').get(cur.code)) };
  }, { admin: true });

  /* Admin: settings */
  route('GET', '/api/admin/settings', () => {
    const s = getSettings();
    return { supportContact: s.support_contact || '', disclaimer: s.disclaimer || '' };
  }, { admin: true });

  route('PATCH', '/api/admin/settings', async (ctx) => {
    const body = await ctx.body();
    const fields = {};
    const upd = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
    const writes = [];
    if (body.supportContact !== undefined) { const r = v.text(body.supportContact, 200, 'Support contact'); if (r.ok) writes.push(['support_contact', r.value]); else fields.supportContact = r.error; }
    if (body.disclaimer !== undefined) { const r = v.text(body.disclaimer, 500, 'Disclaimer'); if (r.ok) writes.push(['disclaimer', r.value]); else fields.disclaimer = r.error; }
    if (Object.keys(fields).length) throw new HttpError(422, 'validation', 'Please fix the highlighted fields.', fields);
    for (const [k, val] of writes) upd.run(k, val);
    const s = getSettings();
    return { supportContact: s.support_contact || '', disclaimer: s.disclaimer || '' };
  }, { admin: true });

  /* ---- dispatcher ---- */
  async function handleApi(req, res, url) {
    const ctx = { req, res, url, ip: clientIp(req), params: {}, session: null, _body: null };
    ctx.body = () => (ctx._body ||= readJson(req));
    try {
      const matches = routes.filter((r) => r.re.test(url.pathname));
      if (!matches.length) throw new HttpError(404, 'not_found', 'Unknown endpoint.');
      const r = matches.find((m) => m.method === req.method);
      if (!r) throw new HttpError(405, 'method_not_allowed', 'Method not allowed.', undefined, { Allow: matches.map((m) => m.method).join(', ') });
      ctx.params = { ...(url.pathname.match(r.re).groups || {}) };

      if (req.method !== 'GET') {
        const origin = req.headers.origin;
        if (origin) {
          let same = false;
          try { same = new URL(origin).host === requestHost(req); } catch { /* invalid origin */ }
          if (!same) throw new HttpError(403, 'bad_origin', 'Cross-site request blocked.');
        }
      }
      if (r.admin) {
        const session = getSession(req);
        if (!session) throw new HttpError(401, 'unauthorized', 'Please sign in.');
        if (req.method !== 'GET' && !sec.safeEqual(req.headers['x-csrf-token'] || '', session.csrf)) {
          throw new HttpError(403, 'bad_csrf', 'Your security token is missing or expired. Reload the page and try again.');
        }
        ctx.session = session;
      }

      const out = await r.handler(ctx);
      if (out && typeof out === 'object' && 'body' in out) sendJson(res, out.status || 200, out.body, out.headers);
      else sendJson(res, 200, out);
    } catch (err) {
      if (res.headersSent) { res.end(); return; }
      if (err instanceof HttpError) {
        sendJson(res, err.status, { error: { code: err.code, message: err.message, fields: err.fields } }, err.headers);
        if (err.status === 413) res.once('finish', () => req.socket.destroy());
      } else {
        console.error('[error]', err);
        sendJson(res, 500, { error: { code: 'server_error', message: 'Something went wrong on our side. Please try again.' } });
      }
    }
  }

  const purge = setInterval(() => {
    try { db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now()); } catch { /* db closing */ }
  }, 10 * 60_000);
  purge.unref();

  return function onRequest(req, res) {
    setSecurityHeaders(req, res);
    if (typeof req.url !== 'string' || !req.url.startsWith('/') || req.url.startsWith('//')) {
      res.writeHead(400); res.end(); return;
    }
    let url;
    try { url = new URL(req.url, 'http://localhost'); } catch { res.writeHead(400); res.end(); return; }
    if (url.pathname.startsWith('/api/')) { handleApi(req, res, url); return; }
    try { servePublic(req, res, url.pathname); } catch (err) {
      console.error('[error]', err);
      if (!res.headersSent) { res.writeHead(500); }
      res.end();
    }
  };
}

/* ----------------------------------------------------------------- startup */

async function ensureAdmin(db) {
  if (db.prepare('SELECT COUNT(*) AS c FROM admins').get().c > 0) return;
  const username = (process.env.ADMIN_USERNAME || 'admin').trim() || 'admin';
  let password = process.env.ADMIN_PASSWORD || '';
  let generated = false;
  if (password.length < 12) {
    if (password) console.warn('[admin] ADMIN_PASSWORD is shorter than 12 characters, so a random one was generated instead.');
    password = sec.randomToken(15); generated = true;
  }
  db.prepare('INSERT INTO admins (username, password_hash, created_at) VALUES (?, ?, ?)')
    .run(username, await sec.hashPassword(password), nowIso());
  if (generated) {
    console.log('\n  ┌────────────────────────────────────────────────────────┐');
    console.log('  │  First-run admin account created (shown only once)      │');
    console.log(`  │  username: ${username}`);
    console.log(`  │  password: ${password}`);
    console.log('  │  Sign in at /admin, then change the password.           │');
    console.log('  └────────────────────────────────────────────────────────┘\n');
  } else {
    console.log(`[admin] Created admin "${username}" from ADMIN_PASSWORD. Remove ADMIN_PASSWORD from your environment now.`);
  }
}

async function main() {
  const db = openDb(DB_PATH);
  await ensureAdmin(db);
  const dummyHash = await sec.hashPassword(sec.randomToken());
  const server = http.createServer(createApp(db, { dummyHash }));
  server.keepAliveTimeout = 65_000;
  server.headersTimeout = 66_000;
  server.requestTimeout = 30_000;
  server.listen(PORT, HOST, () => {
    console.log(`Store listening on http://localhost:${PORT}  (admin: /admin)`);
  });
  const stop = () => { server.close(() => { try { db.close(); } catch { /* ignore */ } process.exit(0); }); setTimeout(() => process.exit(0), 5000).unref(); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

if (require.main === module) main().catch((e) => { console.error(e); process.exit(1); });
module.exports = { createApp };
