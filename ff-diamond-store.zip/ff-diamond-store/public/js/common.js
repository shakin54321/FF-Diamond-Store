/* Shared helpers for every page. No framework, no innerHTML with data: DOM is built with el(). */
(function () {
  'use strict';

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- DOM builder (text is always inserted as text nodes) ---------- */
  function el(tag, attrs, ...kids) {
    const n = document.createElement(tag);
    let pendingValue;
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v === null || v === undefined || v === false) continue;
        if (k === 'class') n.className = v;
        else if (k === 'text') n.textContent = v;
        else if (k === 'value') pendingValue = v;
        else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2).toLowerCase(), v);
        else if (v === true) n.setAttribute(k, '');
        else n.setAttribute(k, String(v));
      }
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid === null || kid === undefined || kid === false) continue;
      n.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    if (pendingValue !== undefined) n.value = pendingValue;
    return n;
  }

  const SVG_NS = 'http://www.w3.org/2000/svg';
  function icon(name, { size = 20, cls = '' } = {}) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('class', `ico ${name === 'gem' ? 'ico-gem' : ''} ${cls}`.trim());
    svg.setAttribute('width', size);
    svg.setAttribute('height', size);
    svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS(SVG_NS, 'use');
    use.setAttribute('href', `#i-${name}`);
    svg.append(use);
    return svg;
  }

  /* ---------- formatting ---------- */
  const nf = new Intl.NumberFormat('en-US');
  const fmt = {
    int: (n) => nf.format(n),
    taka: (n) => '৳' + nf.format(n),
    date: (iso) => {
      const d = new Date(iso);
      if (Number.isNaN(d.getTime())) return '';
      return d.toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true });
    },
  };

  /* ---------- API ---------- */
  class ApiError extends Error {
    constructor(status, code, message, fields) { super(message); this.status = status; this.code = code; this.fields = fields || {}; }
  }
  async function api(path, { method = 'GET', body, csrf } = {}) {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (csrf) headers['X-CSRF-Token'] = csrf;
    let res;
    try {
      res = await fetch(path, { method, headers, credentials: 'same-origin', body: body !== undefined ? JSON.stringify(body) : undefined });
    } catch {
      throw new ApiError(0, 'network', 'Network problem. Check your connection and try again.');
    }
    let data = null;
    try { data = await res.json(); } catch { /* empty or non-JSON */ }
    if (!res.ok) {
      const e = (data && data.error) || {};
      throw new ApiError(res.status, e.code || 'error', e.message || 'Something went wrong. Please try again.', e.fields);
    }
    return data;
  }

  let cfgPromise = null;
  function config(force) {
    if (!cfgPromise || force) {
      cfgPromise = api('/api/config').catch((e) => { cfgPromise = null; throw e; });
    }
    return cfgPromise;
  }

  /* ---------- toast + clipboard ---------- */
  let toastHost;
  function toast(message, kind) {
    if (!toastHost) {
      toastHost = el('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' });
      document.body.append(toastHost);
    }
    const t = el('div', { class: `toast ${kind || ''}`.trim() }, message);
    toastHost.append(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 260); }, 2200);
  }

  async function copy(text, okMsg) {
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch { /* fall back below */ }
    if (!ok) {
      try {
        const ta = el('textarea', { readonly: true, 'aria-hidden': 'true', value: text, class: 'sr' });
        document.body.append(ta); ta.select(); ok = document.execCommand('copy'); ta.remove();
      } catch { ok = false; }
    }
    toast(ok ? (okMsg || 'Copied') : 'Could not copy. Select the text and copy it manually.', ok ? '' : 'bad');
    return ok;
  }

  /* ---------- scroll reveal ---------- */
  function reveal(root) {
    const items = [...(root || document).querySelectorAll('.reveal:not(.in)')];
    if (!items.length) return;
    if (reduced || !('IntersectionObserver' in window)) { items.forEach((e) => e.classList.add('in')); return; }
    const io = new IntersectionObserver((entries) => {
      for (const en of entries) if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.06 });
    items.forEach((e, i) => { e.style.setProperty('--d', `${(i % 4) * 70}ms`); io.observe(e); });
  }

  /* ---------- background particles (light on purpose: Android / low-end friendly) ---------- */
  function particles() {
    if (reduced) return;
    const cv = el('canvas', { class: 'fx', 'aria-hidden': 'true' });
    document.body.prepend(cv);
    const ctx = cv.getContext('2d');
    if (!ctx) return;
    const low = (navigator.deviceMemory || 4) <= 2 || (navigator.hardwareConcurrency || 4) <= 4 || window.innerWidth < 700;
    const COUNT = low ? 26 : 56;
    const DPR = Math.min(window.devicePixelRatio || 1, low ? 1 : 1.5);
    const FRAME = low ? 1000 / 28 : 1000 / 40;
    let w = 0; let h = 0; let parts = []; let last = 0; let raf = 0;
    const rnd = (a, b) => a + Math.random() * (b - a);
    const make = (initial) => ({
      x: rnd(0, w), y: initial ? rnd(0, h) : h + 10, r: rnd(0.6, 1.8), vy: rnd(0.008, 0.028), vx: rnd(-0.006, 0.006),
      a: rnd(0.25, 0.75), p: rnd(0, 6.28), s: rnd(0.0006, 0.0018), violet: Math.random() < 0.3,
    });
    function size() {
      w = window.innerWidth; h = window.innerHeight;
      cv.width = Math.round(w * DPR); cv.height = Math.round(h * DPR);
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      parts = Array.from({ length: COUNT }, () => make(true));
    }
    function frame(t) {
      raf = requestAnimationFrame(frame);
      if (t - last < FRAME) return;
      const dt = Math.min(64, t - last || FRAME); last = t;
      ctx.clearRect(0, 0, w, h);
      for (const p of parts) {
        p.y -= p.vy * dt; p.x += p.vx * dt;
        if (p.y < -10 || p.x < -10 || p.x > w + 10) Object.assign(p, make(false), { x: rnd(0, w) });
        const a = p.a * (0.55 + 0.45 * Math.sin(t * p.s + p.p));
        ctx.fillStyle = p.violet ? `rgba(170,150,255,${a.toFixed(3)})` : `rgba(140,185,255,${a.toFixed(3)})`;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.2832); ctx.fill();
      }
    }
    const start = () => { if (!raf) { last = 0; raf = requestAnimationFrame(frame); } };
    const stop = () => { cancelAnimationFrame(raf); raf = 0; };
    size(); start();
    document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));
    let rt; let lastW = w;
    window.addEventListener('resize', () => {
      clearTimeout(rt);
      rt = setTimeout(() => { if (window.innerWidth !== lastW) { lastW = window.innerWidth; size(); } }, 200); // ignore mobile URL-bar height jitter
    }, { passive: true });
  }

  /* ---------- soft page transitions between our own pages ---------- */
  function pageTransitions() {
    document.addEventListener('click', (e) => {
      const a = e.target.closest && e.target.closest('a[href]');
      if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || a.target || a.hasAttribute('download')) return;
      let u; try { u = new URL(a.href, location.href); } catch { return; }
      if (u.origin !== location.origin) return;
      if (u.pathname === location.pathname && u.search === location.search) return; // same-page anchor
      if (reduced) return;
      e.preventDefault();
      document.body.classList.add('page-leaving');
      setTimeout(() => { location.href = u.href; }, 140);
    });
    window.addEventListener('pageshow', (e) => { if (e.persisted) document.body.classList.remove('page-leaving'); });
  }

  /* ---------- footer: admin-editable text ---------- */
  async function hydrateFooter() {
    try {
      const cfg = await config();
      const sup = document.querySelector('[data-support]');
      if (sup && cfg.supportContact) { sup.textContent = `Need help? ${cfg.supportContact}`; sup.hidden = false; }
      const dis = document.querySelector('[data-disclaimer]');
      if (dis && cfg.disclaimer) dis.textContent = cfg.disclaimer;
    } catch { /* footer keeps its static text */ }
  }

  /* ---------- recent orders on this device ---------- */
  const RECENT_KEY = 'ff_recent_orders';
  const recent = {
    get() { try { const a = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'); return Array.isArray(a) ? a.filter((x) => typeof x === 'string').slice(0, 8) : []; } catch { return []; } },
    add(id) { try { const a = [id, ...recent.get().filter((x) => x !== id)].slice(0, 8); localStorage.setItem(RECENT_KEY, JSON.stringify(a)); } catch { /* storage blocked */ } },
  };

  window.FF = { el, icon, fmt, api, ApiError, config, toast, copy, reveal, recent, reduced };

  document.addEventListener('DOMContentLoaded', () => {
    pageTransitions();
    if (!document.body.hasAttribute('data-nofx')) particles();
    reveal();
    hydrateFooter();
  });
})();
