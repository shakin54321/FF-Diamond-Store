(function () {
  'use strict';
  const { el, icon, fmt, api, recent, copy } = window.FF;

  const form = document.getElementById('trackForm');
  const input = document.getElementById('orderId');
  const btn = document.getElementById('trackBtn');
  const msg = document.getElementById('trackMsg');
  const out = document.getElementById('result');
  const recentBox = document.getElementById('recent');

  const FLOW = ['pending', 'under_review', 'verified', 'completed'];
  const FLOW_LABEL = { pending: 'Pending', under_review: 'Under Review', verified: 'Verified', completed: 'Completed' };
  const HELP = {
    pending: 'We have your order and are waiting for a team member to start checking your payment.',
    under_review: 'Our team is checking your payment against your Transaction ID.',
    verified: 'Your payment is verified. Your diamonds are being delivered to your UID.',
    completed: 'All done. Your diamonds have been delivered to your Free Fire account.',
    rejected: 'We could not verify this payment, so the order was not processed.',
  };

  let current = null; let timer = 0;

  const normId = (s) => s.replace(/\s+/g, '').toUpperCase();
  const ID_RE = /^FF-[2-9A-HJ-NP-Z]{8}$/;

  function showMsg(text) {
    msg.replaceChildren(text ? el('div', { class: 'alert alert-bad sticky-note' }, icon('alert', { size: 18 }), el('span', null, text)) : '');
  }

  function stepper(order) {
    if (order.status === 'rejected') {
      return el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, HELP.rejected));
    }
    const idx = FLOW.indexOf(order.status);
    return el('ol', { class: 'stepper', 'aria-label': 'Order progress' },
      FLOW.map((s, i) => {
        const done = i <= idx;
        const cur = i === idx;
        const finished = order.status === 'completed';
        return el('li', { class: `${done ? 'done' : ''} ${cur ? 'current' : ''} ${cur && finished ? 'finished' : ''}`.trim(), 'aria-current': cur ? 'step' : null },
          FLOW_LABEL[s]);
      }));
  }

  function render(order) {
    current = order;
    out.replaceChildren(el('section', { class: 'panel result' },
      el('div', { class: 'res-head' },
        el('div', null, el('span', { class: 'hint' }, 'Order ID'), el('br'), el('span', { class: 'id' }, order.id),
          ' ', el('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Copy Order ID', onclick: () => copy(order.id, 'Order ID copied') }, icon('copy', { size: 16 }))),
        el('span', { class: `badge b-${order.status}` }, order.statusLabel)),
      stepper(order),
      el('p', { class: 'page-sub', style: null }, HELP[order.status] || ''),
      order.note ? el('div', { class: 'alert alert-warn sticky-note' }, icon('alert', { size: 18 }), el('span', null, el('b', null, 'Message from support: '), order.note)) : null,
      el('dl', { class: 'det sticky-note' },
        el('div', null, el('dt', null, 'Package'), el('dd', null, `${fmt.int(order.unitDiamonds)} Diamonds × ${order.quantity}`)),
        el('div', null, el('dt', null, 'Total diamonds'), el('dd', null, fmt.int(order.totalDiamonds))),
        el('div', null, el('dt', null, 'Total amount'), el('dd', null, fmt.taka(order.totalPrice))),
        el('div', null, el('dt', null, 'Paid with'), el('dd', null, order.paymentMethod)),
        el('div', null, el('dt', null, 'Transaction ID'), el('dd', null, order.trxId)),
        el('div', null, el('dt', null, 'Player UID'), el('dd', null, order.playerUid)),
        el('div', null, el('dt', null, 'Placed'), el('dd', null, fmt.date(order.createdAt))),
        el('div', null, el('dt', null, 'Last update'), el('dd', null, fmt.date(order.updatedAt)))),
      el('h2', { class: 'sticky-note', style: null }, 'History'),
      el('ol', { class: 'timeline' }, order.timeline.slice().reverse().map((e) =>
        el('li', null, el('b', null, e.statusLabel), el('time', { datetime: e.at }, fmt.date(e.at)), e.note ? el('p', null, e.note) : null)))));
  }

  function schedulePoll() {
    clearTimeout(timer);
    if (!current || current.status === 'completed' || current.status === 'rejected') return;
    timer = setTimeout(async () => {
      if (!document.hidden && current) {
        try {
          const { order } = await api(`/api/orders/${current.id}`);
          if (order.updatedAt !== current.updatedAt) render(order);
        } catch { /* keep showing what we have */ }
      }
      schedulePoll();
    }, 30000);
  }

  async function lookup(rawId, { push } = { push: true }) {
    const id = normId(rawId);
    showMsg('');
    if (!id) { showMsg('Enter your Order ID.'); input.focus(); return; }
    if (!ID_RE.test(id)) { showMsg('That does not look like a valid Order ID. It starts with FF- followed by 8 characters.'); input.focus(); return; }
    input.value = id;
    btn.disabled = true;
    btn.replaceChildren(el('span', { class: 'spin', 'aria-hidden': 'true' }), 'Checking…');
    try {
      const { order } = await api(`/api/orders/${id}`);
      if (push) history.replaceState(null, '', `/track/${order.id}`);
      recent.add(order.id); renderRecent();
      render(order); schedulePoll();
    } catch (err) {
      out.replaceChildren(); current = null; clearTimeout(timer);
      showMsg(err.message);
    } finally {
      btn.disabled = false;
      btn.replaceChildren(icon('search', { size: 18 }), 'Track');
    }
  }

  function renderRecent() {
    const ids = recent.get();
    recentBox.hidden = ids.length === 0;
    recentBox.replaceChildren(ids.length ? 'Recent on this device:' : '',
      ...ids.map((id) => el('button', { type: 'button', class: 'chip-btn', onclick: () => lookup(id) }, id)));
  }

  input.addEventListener('input', () => {
    const pos = input.selectionStart; const v = input.value.toUpperCase().replace(/\s+/g, '');
    if (v !== input.value) { input.value = v; try { input.setSelectionRange(pos, pos); } catch { /* unsupported */ } }
  });
  form.addEventListener('submit', (e) => { e.preventDefault(); lookup(input.value); });

  renderRecent();
  const fromPath = decodeURIComponent(location.pathname.split('/')[2] || '');
  const fromQuery = new URLSearchParams(location.search).get('id') || '';
  const initial = fromPath || fromQuery;
  if (initial) { input.value = normId(initial); lookup(initial, { push: false }); }
})();
