(function () {
  'use strict';
  const { el, icon, fmt, api, ApiError, toast, copy } = window.FF;
  const root = document.getElementById('adminRoot');
  const dlg = document.getElementById('orderDlg');
  const dlgBody = document.getElementById('orderDlgBody');

  const STATUSES = [['pending', 'Pending'], ['under_review', 'Under Review'], ['verified', 'Verified'], ['completed', 'Completed'], ['rejected', 'Rejected']];
  const LABEL = Object.fromEntries(STATUSES);
  const METHOD_NAME = { bkash: 'bKash', nagad: 'Nagad', rocket: 'Rocket' };

  let session = null;            // { username, csrf }
  let tab = 'orders';
  const ordersState = { status: '', q: '', offset: 0, limit: 30 };

  /* ---- API wrapper: any auth failure returns to the login screen ---- */
  async function call(path, opts = {}) {
    try {
      return await api(path, { ...opts, csrf: session && session.csrf });
    } catch (e) {
      if (e instanceof ApiError && (e.status === 401 || e.code === 'bad_csrf')) {
        session = null;
        if (dlg.open) dlg.close();
        renderLogin(e.status === 401 ? 'Your session has ended. Please sign in again.' : e.message);
      }
      throw e;
    }
  }
  const msgOf = (e) => (e && e.message) || 'Something went wrong.';
  const fieldErrs = (form, e) => {
    form.querySelectorAll('[data-err]').forEach((n) => { n.textContent = ''; });
    form.querySelectorAll('[aria-invalid]').forEach((n) => n.removeAttribute('aria-invalid'));
    if (!(e instanceof ApiError) || !e.fields) return false;
    let any = false;
    for (const [k, m] of Object.entries(e.fields)) {
      const t = form.querySelector(`[data-err="${k}"]`); const i = form.querySelector(`[name="${k}"]`);
      if (t) { t.textContent = m; any = true; }
      if (i) i.setAttribute('aria-invalid', 'true');
    }
    return any;
  };
  const busy = (btn, on, text) => {
    btn.disabled = on;
    if (on) btn.replaceChildren(el('span', { class: 'spin', 'aria-hidden': 'true' }), text || 'Saving…');
    else btn.replaceChildren(btn.dataset.label);
  };
  const saveBtn = (label = 'Save changes') => el('button', { type: 'submit', class: 'btn btn-primary btn-sm', 'data-label': label }, label);
  const field = (label, name, input, hint) => el('div', { class: 'field' },
    el('label', { for: input.id }, label), input, el('p', { class: 'err', 'data-err': name }), hint ? el('p', { class: 'hint' }, hint) : null);
  const badge = (s) => el('span', { class: `badge b-${s}` }, LABEL[s] || s);

  /* =================== login =================== */
  function renderLogin(notice) {
    document.title = 'Admin sign in | FF Diamond';
    const u = el('input', { class: 'input', id: 'lu', name: 'username', autocomplete: 'username', required: true, autocapitalize: 'none', spellcheck: 'false' });
    const p = el('input', { class: 'input', id: 'lp', name: 'password', type: 'password', autocomplete: 'current-password', required: true });
    const alertBox = el('div', { role: 'alert' });
    const btn = el('button', { type: 'submit', class: 'btn btn-primary btn-block', 'data-label': 'Sign in' }, 'Sign in');
    if (notice) alertBox.append(el('div', { class: 'alert alert-warn' }, icon('alert', { size: 18 }), el('span', null, notice)));
    const form = el('form', { class: 'panel login', novalidate: true },
      el('h1', null, 'Admin sign in'), el('p', { class: 'page-sub' }, 'Authorised staff only.'),
      el('div', { class: 'field' }, el('label', { for: 'lu' }, 'Username'), u),
      el('div', { class: 'field' }, el('label', { for: 'lp' }, 'Password'), p),
      alertBox, el('div', { class: 'submit-row' }, btn));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      alertBox.replaceChildren();
      if (!u.value.trim() || !p.value) { alertBox.append(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, 'Enter your username and password.'))); return; }
      busy(btn, true, 'Signing in…');
      try {
        session = await api('/api/admin/login', { method: 'POST', body: { username: u.value.trim(), password: p.value } });
        p.value = '';
        renderShell();
      } catch (err) {
        busy(btn, false);
        alertBox.append(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, msgOf(err))));
        p.value = ''; p.focus();
      }
    });
    root.replaceChildren(form);
    u.focus();
  }

  /* =================== shell =================== */
  function renderShell() {
    document.title = 'Admin | FF Diamond';
    const TABS = [['orders', 'Orders'], ['packages', 'Packages'], ['methods', 'Payment methods'], ['settings', 'Settings']];
    const pane = el('div', { class: 'ad-pane', role: 'tabpanel' });
    const tabEls = TABS.map(([k, label]) => {
      const t = el('button', { type: 'button', role: 'tab', class: 'tab', 'aria-selected': String(k === tab), 'data-k': k }, label);
      t.addEventListener('click', () => { tab = k; tabEls.forEach((x) => x.setAttribute('aria-selected', String(x.dataset.k === k))); load(pane); });
      return t;
    });
    const logout = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: async () => {
      try { await api('/api/admin/logout', { method: 'POST', body: {}, csrf: session.csrf }); } catch { /* ignore */ }
      session = null; renderLogin();
    } }, 'Sign out');
    root.replaceChildren(
      el('div', { class: 'ad-bar' },
        el('a', { class: 'brand', href: '/' }, icon('gem', { size: 26 }), el('span', { class: 'brand-t' }, 'Admin')),
        el('div', { class: 'who' }, el('span', null, session.username), logout)),
      el('div', { class: 'tabs', role: 'tablist', 'aria-label': 'Admin sections' }, tabEls), pane);
    load(pane);
  }

  function load(pane) {
    pane.replaceChildren(el('p', { class: 'hint' }, 'Loading…'));
    ({ orders: loadOrders, packages: loadPackages, methods: loadMethods, settings: loadSettings }[tab])(pane);
  }
  const failed = (pane, e, retry) => pane.replaceChildren(el('div', { class: 'empty', role: 'alert' }, el('p', null, msgOf(e)),
    el('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: retry }, 'Try again')));

  /* =================== orders =================== */
  async function loadOrders(pane) {
    const qs = new URLSearchParams({ limit: ordersState.limit, offset: ordersState.offset });
    if (ordersState.status) qs.set('status', ordersState.status);
    if (ordersState.q) qs.set('q', ordersState.q);
    let data;
    try { data = await call(`/api/admin/orders?${qs}`); } catch (e) { if (session) failed(pane, e, () => load(pane)); return; }

    const reload = () => loadOrders(pane);
    const allCount = Object.values(data.counts).reduce((a, b) => a + b, 0);
    const chip = (val, label, count) => el('button', { type: 'button', class: 'fchip', 'aria-pressed': String(ordersState.status === val),
      onclick: () => { ordersState.status = val; ordersState.offset = 0; reload(); } }, label, el('span', { class: 'c' }, count));
    const search = el('input', { class: 'input', type: 'search', placeholder: 'Search Order ID, UID or TrxID', 'aria-label': 'Search orders', value: ordersState.q, maxlength: 40 });
    let t; search.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { ordersState.q = search.value.trim(); ordersState.offset = 0; reload(); }, 350); });

    const list = data.orders.length
      ? el('div', { class: 'orders' }, data.orders.map((o) => el('button', { type: 'button', class: 'orow', onclick: () => openOrder(o.id, reload) },
          el('span', { class: 'id' }, o.id), badge(o.status),
          el('span', { class: 'meta' },
            el('span', null, el('b', null, fmt.taka(o.totalPrice)), ` · ${fmt.int(o.totalDiamonds)} diamonds`),
            el('span', null, 'UID ', el('b', { class: 'mono' }, o.playerUid)),
            el('span', null, METHOD_NAME[o.paymentMethod] || o.paymentMethod, ' ', el('b', { class: 'mono' }, o.trxId)),
            el('span', null, fmt.date(o.createdAt))))))
      : el('div', { class: 'empty' }, ordersState.status || ordersState.q ? 'No orders match these filters.' : 'No orders yet. They will appear here as customers submit payments.');

    const from = data.total ? ordersState.offset + 1 : 0;
    const to = Math.min(data.total, ordersState.offset + ordersState.limit);
    const pager = el('div', { class: 'pager' },
      el('span', null, `${from}–${to} of ${data.total}`),
      el('span', { class: 'rc-actions' },
        el('button', { type: 'button', class: 'btn btn-ghost btn-sm', disabled: ordersState.offset === 0, onclick: () => { ordersState.offset = Math.max(0, ordersState.offset - ordersState.limit); reload(); } }, 'Previous'),
        el('button', { type: 'button', class: 'btn btn-ghost btn-sm', disabled: to >= data.total, onclick: () => { ordersState.offset += ordersState.limit; reload(); } }, 'Next')));

    const hadFocus = document.activeElement === search;
    pane.replaceChildren(
      el('div', { class: 'filters' }, chip('', 'All', allCount), STATUSES.map(([k, l]) => chip(k, l, data.counts[k] || 0)), search),
      list, pager);
    if (hadFocus) { const s = pane.querySelector('input[type=search]'); s.focus(); s.setSelectionRange(s.value.length, s.value.length); }
  }

  async function openOrder(id, onChange) {
    let order;
    try { ({ order } = await call(`/api/admin/orders/${id}`)); } catch (e) { if (session) toast(msgOf(e), 'bad'); return; }
    renderOrderDialog(order, onChange);
    if (!dlg.open) dlg.showModal();
  }

  function renderOrderDialog(order, onChange) {
    const sel = el('select', { class: 'input', id: 'od-status', name: 'status' }, STATUSES.map(([k, l]) => el('option', { value: k, selected: k === order.status }, l)));
    const note = el('textarea', { class: 'input', id: 'od-note', name: 'note', maxlength: 300, placeholder: 'Optional message shown to the customer on the tracking page', value: order.note });
    const quick = [['under_review', 'Mark Under Review'], ['verified', 'Mark Verified'], ['completed', 'Mark Completed']];
    const form = el('form', { novalidate: true },
      el('div', { class: 'od-sec' }, el('h3', null, 'Update order'),
        el('div', { class: 'od-quick' }, quick.filter(([k]) => k !== order.status).map(([k, l]) => el('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: () => { sel.value = k; } }, l)),
          order.status !== 'rejected' ? el('button', { type: 'button', class: 'btn btn-danger btn-sm', onclick: () => { sel.value = 'rejected'; note.focus(); } }, 'Reject') : null),
        field('Status', 'status', sel),
        el('div', { style: null, class: 'sticky-note' }, field('Note to customer (public)', 'note', note))),
      el('div', { class: 'rc-actions sticky-note' }, saveBtn('Save'), el('span', { class: 'hint' }, 'Status changes are logged in the history.')),
      el('div', { role: 'alert', 'data-alert': true }));
    const alertHost = form.querySelector('[data-alert]');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type=submit]');
      alertHost.replaceChildren(); busy(btn, true);
      try {
        const res = await call(`/api/admin/orders/${order.id}`, { method: 'PATCH', body: { status: sel.value, note: note.value } });
        toast('Order updated');
        renderOrderDialog(res.order, onChange);
        onChange();
      } catch (err) {
        busy(btn, false);
        if (!fieldErrs(form, err) && session) alertHost.replaceChildren(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, msgOf(err))));
      }
    });

    const copyable = (text) => el('span', { class: 'od-copyable' }, el('span', { class: 'mono' }, text),
      el('button', { type: 'button', class: 'icon-btn', 'aria-label': `Copy ${text}`, onclick: () => copy(text, 'Copied') }, icon('copy', { size: 14 })));

    dlgBody.replaceChildren(
      el('button', { type: 'button', class: 'icon-btn dlg-x', 'aria-label': 'Close', onclick: () => dlg.close() }, icon('x', { size: 18 })),
      el('h2', { id: 'odTitle' }, order.id, badge(order.status)),
      el('dl', { class: 'det sticky-note' },
        el('div', null, el('dt', null, 'Package'), el('dd', null, `${fmt.int(order.unitDiamonds)} × ${order.quantity} = ${fmt.int(order.totalDiamonds)} diamonds`)),
        el('div', null, el('dt', null, 'Amount to match'), el('dd', null, fmt.taka(order.totalPrice))),
        el('div', null, el('dt', null, 'Player UID'), el('dd', null, copyable(order.playerUid))),
        el('div', null, el('dt', null, 'Method'), el('dd', null, METHOD_NAME[order.paymentMethod] || order.paymentMethod)),
        el('div', null, el('dt', null, 'Transaction ID'), el('dd', null, copyable(order.trxId))),
        el('div', null, el('dt', null, 'Placed'), el('dd', null, fmt.date(order.createdAt)))),
      el('div', { class: 'alert alert-warn sticky-note' }, icon('alert', { size: 18 }),
        el('span', null, 'Match the Transaction ID and amount against your own bKash / Nagad / Rocket records before marking Verified.')),
      form,
      el('div', { class: 'od-sec' }, el('h3', null, 'History'),
        el('ol', { class: 'od-events' }, order.events.slice().reverse().map((ev) => el('li', null,
          el('b', null, LABEL[ev.to]), ` · ${ev.actor} · ${fmt.date(ev.at)}`, ev.note ? el('div', null, `“${ev.note}”`) : null)))));
  }
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });
  dlg.addEventListener('close', () => { document.body.classList.remove('lock'); });
  dlg.addEventListener('toggle', () => { if (dlg.open) document.body.classList.add('lock'); });

  /* =================== packages =================== */
  async function loadPackages(pane) {
    let data;
    try { data = await call('/api/admin/packages'); } catch (e) { if (session) failed(pane, e, () => load(pane)); return; }
    const reload = () => loadPackages(pane);

    function row(p) {
      const d = el('input', { class: 'input', id: `pd${p.id}`, name: 'diamonds', inputmode: 'numeric', value: p.diamonds });
      const pr = el('input', { class: 'input', id: `pp${p.id}`, name: 'price', inputmode: 'numeric', value: p.price });
      const so = el('input', { class: 'input', id: `ps${p.id}`, name: 'sortOrder', inputmode: 'numeric', value: p.sortOrder });
      const av = el('input', { type: 'checkbox', checked: p.available, 'aria-label': 'Available for sale' });
      const alertHost = el('div', { role: 'alert' });
      const form = el('form', { class: 'rowcard', novalidate: true },
        el('h3', null, `${fmt.int(p.diamonds)} diamonds`, el('span', { class: `tag ${p.available ? 'ok' : 'warn'}` }, p.available ? 'On sale' : 'Hidden from sale')),
        el('div', { class: 'rc-grid cols-4' },
          field('Diamonds', 'diamonds', d), field('Price (৳)', 'price', pr), field('Sort order', 'sortOrder', so),
          el('div', { class: 'field' }, el('label', null, 'Availability'), el('label', { class: 'switch' }, av, 'Available'))),
        alertHost,
        el('div', { class: 'rc-actions' }, saveBtn(),
          el('span', { class: 'grow' }),
          el('button', { type: 'button', class: 'btn btn-danger btn-sm', onclick: async () => {
            if (!confirm(`Delete the ${fmt.int(p.diamonds)}-diamond package? This cannot be undone.`)) return;
            try { await call(`/api/admin/packages/${p.id}`, { method: 'DELETE' }); toast('Package deleted'); reload(); }
            catch (err) { if (session) alertHost.replaceChildren(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, msgOf(err)))); }
          } }, 'Delete')));
      form.addEventListener('submit', async (e) => {
        e.preventDefault(); alertHost.replaceChildren();
        const btn = form.querySelector('button[type=submit]'); busy(btn, true);
        try {
          await call(`/api/admin/packages/${p.id}`, { method: 'PATCH', body: { diamonds: d.value, price: pr.value, sortOrder: so.value, available: av.checked } });
          toast('Package saved'); reload();
        } catch (err) {
          busy(btn, false);
          if (!fieldErrs(form, err) && session) alertHost.replaceChildren(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, msgOf(err))));
        }
      });
      return form;
    }

    // add new
    const nd = el('input', { class: 'input', id: 'nd', name: 'diamonds', inputmode: 'numeric', placeholder: 'e.g. 2500' });
    const np = el('input', { class: 'input', id: 'np', name: 'price', inputmode: 'numeric', placeholder: 'e.g. 450' });
    const ns = el('input', { class: 'input', id: 'ns', name: 'sortOrder', inputmode: 'numeric', value: (data.packages.length ? Math.max(...data.packages.map((p) => p.sortOrder)) + 1 : 1) });
    const addAlert = el('div', { role: 'alert' });
    const addForm = el('form', { class: 'panel', novalidate: true },
      el('h2', null, 'Add a package'),
      el('div', { class: 'rc-grid cols-3' }, field('Diamonds', 'diamonds', nd), field('Price (৳)', 'price', np), field('Sort order', 'sortOrder', ns)),
      addAlert, el('div', { class: 'rc-actions sticky-note' }, saveBtn('Add package')));
    addForm.addEventListener('submit', async (e) => {
      e.preventDefault(); addAlert.replaceChildren();
      const btn = addForm.querySelector('button[type=submit]'); busy(btn, true);
      try { await call('/api/admin/packages', { method: 'POST', body: { diamonds: nd.value, price: np.value, sortOrder: ns.value } }); toast('Package added'); reload(); }
      catch (err) { busy(btn, false); if (!fieldErrs(addForm, err) && session) addAlert.replaceChildren(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, msgOf(err)))); }
    });

    pane.replaceChildren(
      el('p', { class: 'hint' }, 'Price changes apply to new orders only. Existing orders keep the price they were placed at.'),
      el('div', { class: 'rows sticky-note' }, data.packages.map(row)), el('div', { class: 'sticky-note' }, addForm));
  }

  /* =================== payment methods =================== */
  async function loadMethods(pane) {
    let data;
    try { data = await call('/api/admin/payment-methods'); } catch (e) { if (session) failed(pane, e, () => load(pane)); return; }
    const reload = () => loadMethods(pane);

    const card = (m) => {
      const num = el('input', { class: 'input mono', id: `mn-${m.code}`, name: 'number', inputmode: 'tel', value: m.number, placeholder: '01XXXXXXXXX', autocomplete: 'off' });
      const type = el('select', { class: 'input', id: `mt-${m.code}`, name: 'accountType' }, ['Personal', 'Agent', 'Merchant'].map((t) => el('option', { value: t, selected: t === m.accountType }, t)));
      const logo = el('input', { class: 'input', id: `ml-${m.code}`, name: 'logoUrl', value: m.logoUrl, placeholder: '/img/bkash.svg or https://…', autocomplete: 'off', spellcheck: 'false' });
      const ins = el('textarea', { class: 'input', id: `mi-${m.code}`, name: 'instructions', maxlength: 800, rows: 6, value: m.instructions });
      const en = el('input', { type: 'checkbox', checked: m.enabled, 'aria-label': `${m.name} enabled` });
      const alertHost = el('div', { role: 'alert' });
      const live = m.enabled && m.number;
      const form = el('form', { class: 'rowcard', novalidate: true },
        el('h3', null, m.name, el('span', { class: `tag ${live ? 'ok' : 'warn'}` }, live ? 'Visible to customers' : (m.enabled ? 'Hidden: no number set' : 'Disabled'))),
        el('div', { class: 'rc-grid' },
          field('Merchant payment number', 'number', num, 'Customers see this number and can copy it.'),
          field('Account type', 'accountType', type),
          el('div', { class: 'span-all' }, field('Logo (optional)', 'logoUrl', logo, 'Only use an official logo you have permission to use. Upload the file to public/img/ and enter /img/name.svg, or paste an https URL. Without a logo the name is shown as text.')),
          el('div', { class: 'span-all' }, field('Payment instructions (one step per line)', 'instructions', ins)),
          el('div', { class: 'field' }, el('label', null, 'Status'), el('label', { class: 'switch' }, en, 'Enabled'))),
        alertHost, el('div', { class: 'rc-actions' }, saveBtn()));
      form.addEventListener('submit', async (e) => {
        e.preventDefault(); alertHost.replaceChildren();
        const btn = form.querySelector('button[type=submit]'); busy(btn, true);
        try {
          await call(`/api/admin/payment-methods/${m.code}`, { method: 'PATCH', body: { number: num.value, accountType: type.value, logoUrl: logo.value, instructions: ins.value, enabled: en.checked } });
          toast(`${m.name} saved`); reload();
        } catch (err) {
          busy(btn, false);
          if (!fieldErrs(form, err) && session) alertHost.replaceChildren(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, msgOf(err))));
        }
      });
      return form;
    };
    pane.replaceChildren(
      el('div', { class: 'alert alert-warn' }, icon('alert', { size: 18 }), el('span', null, 'A method only appears to customers when it is enabled and has a number. Use accounts you own and monitor.')),
      el('div', { class: 'rows sticky-note' }, data.methods.map(card)));
  }

  /* =================== settings + password =================== */
  async function loadSettings(pane) {
    let s;
    try { s = await call('/api/admin/settings'); } catch (e) { if (session) failed(pane, e, () => load(pane)); return; }
    const sc = el('input', { class: 'input', id: 'sc', name: 'supportContact', value: s.supportContact, maxlength: 200, placeholder: 'e.g. WhatsApp +8801XXXXXXXXX or support@example.com' });
    const dc = el('textarea', { class: 'input', id: 'dc', name: 'disclaimer', maxlength: 500, rows: 3, value: s.disclaimer });
    const a1 = el('div', { role: 'alert' });
    const f1 = el('form', { class: 'panel', novalidate: true },
      el('h2', null, 'Storefront text'),
      el('div', { class: 'form-grid' }, el('div', { class: 'span-2' }, field('Support contact (shown in footer)', 'supportContact', sc)), el('div', { class: 'span-2' }, field('Footer disclaimer', 'disclaimer', dc))),
      a1, el('div', { class: 'rc-actions sticky-note' }, saveBtn()));
    f1.addEventListener('submit', async (e) => {
      e.preventDefault(); a1.replaceChildren();
      const btn = f1.querySelector('button[type=submit]'); busy(btn, true);
      try { await call('/api/admin/settings', { method: 'PATCH', body: { supportContact: sc.value, disclaimer: dc.value } }); toast('Settings saved'); busy(btn, false); }
      catch (err) { busy(btn, false); if (!fieldErrs(f1, err) && session) a1.replaceChildren(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, msgOf(err)))); }
    });

    const cur = el('input', { class: 'input', id: 'cp', name: 'currentPassword', type: 'password', autocomplete: 'current-password' });
    const nw = el('input', { class: 'input', id: 'np2', name: 'newPassword', type: 'password', autocomplete: 'new-password' });
    const a2 = el('div', { role: 'alert' });
    const f2 = el('form', { class: 'panel', novalidate: true },
      el('h2', null, 'Change password'),
      el('div', { class: 'form-grid' }, field('Current password', 'currentPassword', cur), field('New password (12+ characters)', 'newPassword', nw)),
      a2, el('div', { class: 'rc-actions sticky-note' }, saveBtn('Change password'), el('span', { class: 'hint' }, 'Other signed-in sessions are ended.')));
    f2.addEventListener('submit', async (e) => {
      e.preventDefault(); a2.replaceChildren();
      const btn = f2.querySelector('button[type=submit]'); busy(btn, true);
      try { await call('/api/admin/password', { method: 'POST', body: { currentPassword: cur.value, newPassword: nw.value } }); toast('Password changed'); cur.value = ''; nw.value = ''; busy(btn, false); fieldErrs(f2, null); }
      catch (err) { busy(btn, false); if (!fieldErrs(f2, err) && session) a2.replaceChildren(el('div', { class: 'alert alert-bad' }, icon('alert', { size: 18 }), el('span', null, msgOf(err)))); }
    });
    pane.replaceChildren(f1, f2);
  }

  /* =================== boot =================== */
  (async () => {
    try { session = await api('/api/admin/me'); renderShell(); } catch { renderLogin(); }
  })();
})();
