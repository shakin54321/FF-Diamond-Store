(function () {
  'use strict';
  const { el, icon, fmt, api, ApiError, config, copy, recent } = window.FF;
  const root = document.getElementById('payRoot');

  const UID_RE = /^\d{6,14}$/;
  const TRX_RE = /^[A-Z0-9]{8,14}$/;
  const normTrx = (s) => s.replace(/\s+/g, '').toUpperCase();

  function token() {
    try { if (crypto.randomUUID) return crypto.randomUUID(); } catch { /* insecure context */ }
    const b = new Uint8Array(16); crypto.getRandomValues(b);
    return [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
  }

  function stateBox(title, text, actions) {
    root.replaceChildren(el('div', { class: 'panel done' },
      el('h2', null, title), el('p', { class: 'lead' }, text),
      el('div', { class: 'done-actions' }, actions)));
  }

  async function init() {
    const sp = new URLSearchParams(location.search);
    const pkgId = Number(sp.get('pkg'));
    const qty = Number(sp.get('qty') || 1);
    if (!Number.isInteger(pkgId) || pkgId < 1) {
      return stateBox('No package selected', 'Pick a diamond package first, then come back to pay.',
        [el('a', { class: 'btn btn-primary', href: '/#packages' }, 'Choose a package')]);
    }

    root.replaceChildren(el('div', { class: 'panel sk', style: null, 'aria-busy': 'true' }, el('p', { class: 'sr' }, 'Loading payment details')));

    let cfg; let methods;
    try {
      [cfg, { methods }] = await Promise.all([config(true), api('/api/payment-methods')]);
    } catch (e) {
      return stateBox('We could not load payment details', e.message,
        [el('button', { type: 'button', class: 'btn btn-primary', onclick: init }, icon('refresh', { size: 16 }), 'Try again')]);
    }

    const pkg = cfg.packages.find((p) => p.id === pkgId);
    const q = Number.isInteger(qty) && qty >= 1 && qty <= cfg.maxQty ? qty : 1;
    if (!pkg || !pkg.available) {
      return stateBox('That package is not available', 'It may have been removed or is temporarily unavailable. Please choose another.',
        [el('a', { class: 'btn btn-primary', href: '/#packages' }, 'Back to packages')]);
    }
    render({ pkg, qty: q, methods, cfg });
  }

  function render({ pkg, qty, methods, cfg }) {
    const totalDiamonds = pkg.diamonds * qty;
    const totalPrice = pkg.price * qty;
    const usable = methods.filter((m) => m.available);
    let selected = usable[0] || null;
    const clientToken = token();

    /* ---------- summary ---------- */
    const summary = el('aside', { class: 'panel summary', 'aria-label': 'Order summary' },
      el('h2', null, icon('receipt', { size: 20 }), 'Order summary'),
      el('dl', { class: 'sum-list' },
        el('div', null, el('dt', null, 'Package'), el('dd', null, `${fmt.int(pkg.diamonds)} Diamonds`)),
        el('div', null, el('dt', null, 'Quantity'), el('dd', null, `${qty}x`)),
        el('div', null, el('dt', null, 'Total diamonds'), el('dd', null, `${fmt.int(totalDiamonds)} Diamonds`))),
      el('div', { class: 'sum-total' }, el('span', null, 'Total to pay'), el('strong', null, fmt.taka(totalPrice))),
      el('a', { class: 'back sticky-note', href: '/#packages' }, icon('back', { size: 16 }), 'Change package'));

    /* ---------- method cards ---------- */
    const detailsHost = el('div', { 'aria-live': 'polite' });
    const methodBtns = methods.map((m) => {
      const logo = m.logoUrl
        ? el('img', { src: m.logoUrl, alt: `${m.name} logo`, loading: 'lazy', width: 110, height: 32 })
        : el('span', { class: 'm-word' }, m.name);
      const btn = el('button', {
        type: 'button', role: 'radio', class: `method m-${m.code}`, disabled: !m.available,
        'aria-checked': 'false', 'data-code': m.code,
      },
        el('span', { class: 'm-logo' }, logo),
        el('span', { class: 'm-meta' }, el('b', null, m.name), el('small', null, m.available ? `${m.accountType} number` : 'Currently unavailable')),
        el('span', { class: 'm-tick' }, icon('check', { size: 13 })));
      btn.addEventListener('click', () => select(m));
      return btn;
    });
    const methodGroup = el('div', { class: 'methods', role: 'radiogroup', 'aria-label': 'Payment method' }, methodBtns);
    // arrow-key navigation for the radio group
    methodGroup.addEventListener('keydown', (e) => {
      if (!['ArrowRight', 'ArrowDown', 'ArrowLeft', 'ArrowUp'].includes(e.key)) return;
      const enabled = methodBtns.filter((b) => !b.disabled);
      const i = enabled.indexOf(document.activeElement);
      if (i < 0) return;
      e.preventDefault();
      const next = enabled[(i + (e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : enabled.length - 1)) % enabled.length];
      next.focus(); next.click();
    });

    function details(m) {
      const lines = (m.instructions || '').split('\n').map((s) => s.trim()).filter(Boolean);
      return el('div', { class: 'pay-details' },
        el('p', { class: 'pay-amount' }, 'Send exactly ', el('b', null, fmt.taka(totalPrice)), ` with ${m.name} to:`),
        el('div', { class: 'numrow' },
          el('div', null, el('span', { class: 'acct' }, `${m.name} ${m.accountType}`), el('span', { class: 'num' }, m.number)),
          el('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: () => copy(m.number, 'Number copied') }, icon('copy', { size: 16 }), 'Copy Number')),
        lines.length ? el('ol', { class: 'how-list' }, lines.map((l) => el('li', null, l))) : null);
    }

    /* ---------- form ---------- */
    const f = {
      uid: el('input', { class: 'input mono', id: 'uid', name: 'playerUid', inputmode: 'numeric', autocomplete: 'off', maxlength: 14, placeholder: 'e.g. 123456789', required: true, 'aria-describedby': 'uid-e uid-h' }),
      pkg: el('input', { class: 'input', id: 'pkgv', readonly: true, tabindex: -1, value: `${fmt.int(pkg.diamonds)} Diamonds × ${qty} = ${fmt.int(totalDiamonds)} Diamonds` }),
      total: el('input', { class: 'input', id: 'totv', readonly: true, tabindex: -1, value: fmt.taka(totalPrice) }),
      method: el('input', { class: 'input', id: 'methv', readonly: true, tabindex: -1, value: selected ? selected.name : 'Choose a method above' }),
      trx: el('input', { class: 'input mono', id: 'trx', name: 'trxId', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', maxlength: 20, placeholder: 'e.g. 8N7A6D5EE4', required: true, 'aria-describedby': 'trx-e trx-h' }),
    };
    const errs = {
      playerUid: el('p', { class: 'err', id: 'uid-e' }),
      trxId: el('p', { class: 'err', id: 'trx-e' }),
    };
    const formAlert = el('div', { role: 'alert' });
    const submitBtn = el('button', { type: 'submit', class: 'btn btn-primary btn-block' }, 'VERIFY PAYMENT');

    f.trx.addEventListener('input', () => {
      const pos = f.trx.selectionStart; const v = normTrx(f.trx.value);
      if (v !== f.trx.value) { f.trx.value = v; try { f.trx.setSelectionRange(pos, pos); } catch { /* unsupported */ } }
    });
    f.uid.addEventListener('input', () => {
      const v = f.uid.value.replace(/\D/g, '');
      if (v !== f.uid.value) f.uid.value = v;
    });

    function setErr(key, input, msg) {
      errs[key].textContent = msg || '';
      if (msg) input.setAttribute('aria-invalid', 'true'); else input.removeAttribute('aria-invalid');
    }
    // Each check validates ONE field and returns its input when invalid.
    function checkUid() {
      const uid = f.uid.value.trim();
      if (!uid) { setErr('playerUid', f.uid, 'Enter your Free Fire Player UID.'); return f.uid; }
      if (!UID_RE.test(uid)) { setErr('playerUid', f.uid, 'Player UID must be 6 to 14 digits.'); return f.uid; }
      setErr('playerUid', f.uid, ''); return null;
    }
    function checkTrx() {
      const trx = normTrx(f.trx.value);
      if (!trx) { setErr('trxId', f.trx, 'Enter the Transaction ID from your payment confirmation.'); return f.trx; }
      if (!TRX_RE.test(trx)) { setErr('trxId', f.trx, 'Transaction ID must be 8 to 14 letters or numbers, with no symbols.'); return f.trx; }
      setErr('trxId', f.trx, ''); return null;
    }
    function validate() {
      const badUid = checkUid(); const badTrx = checkTrx(); // run both so every error shows at once
      let first = badUid || badTrx;
      if (!selected) {
        formAlert.replaceChildren(alertBox('bad', 'Choose a payment method above.'));
        first ||= methodBtns.find((b) => !b.disabled) || null;
      }
      return first;
    }
    const alertBox = (kind, text) => el('div', { class: `alert alert-${kind}` }, icon('alert', { size: 18 }), el('span', null, text));
    // Blur checks only the field being left, and only once it has content. Typing clears that field's old
    // error, so the layout is stable by the time the user taps Verify (a shift between press and release
    // would swallow the tap on phones).
    f.uid.addEventListener('blur', () => { if (f.uid.value) checkUid(); });
    f.trx.addEventListener('blur', () => { if (f.trx.value) checkTrx(); });
    f.uid.addEventListener('input', () => { if (errs.playerUid.textContent) setErr('playerUid', f.uid, ''); });
    f.trx.addEventListener('input', () => { if (errs.trxId.textContent) setErr('trxId', f.trx, ''); });

    function select(m) {
      selected = m;
      methodBtns.forEach((b) => b.setAttribute('aria-checked', String(b.dataset.code === m.code)));
      methodBtns.forEach((b) => { b.tabIndex = b.dataset.code === m.code ? 0 : -1; });
      detailsHost.replaceChildren(details(m));
      f.method.value = m.name;
      formAlert.replaceChildren();
    }

    const form = el('form', { novalidate: true, autocomplete: 'off' },
      el('div', { class: 'form-grid' },
        el('div', { class: 'field span-2' }, el('label', { for: 'uid' }, 'Free Fire Player UID'), f.uid, errs.playerUid,
          el('p', { class: 'hint', id: 'uid-h' }, 'Diamonds are delivered to this UID. Double-check it.')),
        el('div', { class: 'field span-2' }, el('label', { for: 'pkgv' }, 'Selected Package'), f.pkg),
        el('div', { class: 'field' }, el('label', { for: 'totv' }, 'Total Amount'), f.total),
        el('div', { class: 'field' }, el('label', { for: 'methv' }, 'Payment Method'), f.method),
        el('div', { class: 'field span-2' }, el('label', { for: 'trx' }, 'Transaction ID'), f.trx, errs.trxId,
          el('p', { class: 'hint', id: 'trx-h' }, 'Shown in the confirmation message after you send the money.'))),
      el('div', { class: 'safe' }, icon('shield', { size: 18 }),
        el('span', null, 'Never enter your PIN, OTP or password here. We only need your UID and the Transaction ID. Your order stays Pending until our team verifies the payment.')),
      el('div', { class: 'submit-row' }, formAlert, submitBtn));

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      formAlert.replaceChildren();
      const bad = validate();
      if (bad) { bad.focus(); return; }

      submitBtn.disabled = true;
      submitBtn.replaceChildren(el('span', { class: 'spin', 'aria-hidden': 'true' }), 'Submitting…');
      try {
        const { order } = await api('/api/orders', {
          method: 'POST',
          body: { packageId: pkg.id, quantity: qty, playerUid: f.uid.value.trim(), paymentMethod: selected.code, trxId: normTrx(f.trx.value), clientToken },
        });
        recent.add(order.id);
        success(order, selected);
      } catch (err) {
        submitBtn.disabled = false;
        submitBtn.replaceChildren('VERIFY PAYMENT');
        if (err instanceof ApiError && err.fields) {
          if (err.fields.playerUid) setErr('playerUid', f.uid, err.fields.playerUid);
          if (err.fields.trxId) setErr('trxId', f.trx, err.fields.trxId);
        }
        formAlert.replaceChildren(alertBox('bad', err.message));
        const first = (err.fields && (err.fields.playerUid ? f.uid : err.fields.trxId ? f.trx : null));
        if (first) first.focus();
        if (err.code === 'package_unavailable' || err.code === 'method_unavailable') config(true).catch(() => {});
      }
    });

    /* ---------- success ---------- */
    function success(order, m) {
      window.scrollTo({ top: 0, behavior: window.FF.reduced ? 'auto' : 'smooth' });
      document.title = 'Order received | FF Diamond';
      root.replaceChildren(el('div', { class: 'panel done' },
        el('div', { class: 'done-ring' }, icon('check', { size: 42 })),
        el('h2', null, 'Order received'),
        el('p', { class: 'lead' }, 'Thank you. Your payment has not been confirmed yet. Our team will verify your Transaction ID and update your order status.'),
        el('div', { class: 'order-id' },
          el('div', null, el('span', { class: 'hint' }, 'Your Order ID'), el('br'), el('b', null, order.id)),
          el('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Copy Order ID', onclick: () => copy(order.id, 'Order ID copied') }, icon('copy', { size: 18 }))),
        el('p', null, el('span', { class: `badge b-${order.status}` }, order.statusLabel)),
        el('dl', { class: 'det', style: null },
          el('div', null, el('dt', null, 'Package'), el('dd', null, `${fmt.int(order.unitDiamonds)} Diamonds × ${order.quantity}`)),
          el('div', null, el('dt', null, 'Total diamonds'), el('dd', null, fmt.int(order.totalDiamonds))),
          el('div', null, el('dt', null, 'Total amount'), el('dd', null, fmt.taka(order.totalPrice))),
          el('div', null, el('dt', null, 'Paid with'), el('dd', null, m.name)),
          el('div', null, el('dt', null, 'Transaction ID'), el('dd', null, order.trxId))),
        el('div', { class: 'done-actions' },
          el('a', { class: 'btn btn-primary', href: `/track/${order.id}` }, 'Track this order'),
          el('a', { class: 'btn btn-ghost', href: '/' }, 'Back to store')),
        el('p', { class: 'hint', style: null }, 'Save your Order ID. You will need it to check your status.')));
    }

    /* ---------- assemble ---------- */
    const noMethods = usable.length === 0;
    const main = el('div', { class: 'pay-main' },
      el('section', { class: 'panel', 'aria-labelledby': 'h-method' },
        el('h2', { id: 'h-method' }, el('span', { class: 'n' }, '1'), 'Choose a payment method'),
        methodGroup,
        noMethods ? el('div', { class: 'alert alert-warn sticky-note' }, icon('alert', { size: 18 }), el('span', null, 'Payments are temporarily unavailable. Please try again later or contact support.')) : null,
        detailsHost),
      el('section', { class: 'panel', 'aria-labelledby': 'h-form' },
        el('h2', { id: 'h-form' }, el('span', { class: 'n' }, '2'), 'Confirm your details'),
        form));
    root.replaceChildren(el('div', { class: 'pay-grid' }, main, summary));

    if (noMethods) { submitBtn.disabled = true; f.uid.disabled = true; f.trx.disabled = true; }
    if (selected) select(selected);
    methodBtns.forEach((b) => { if (!b.disabled && b.getAttribute('aria-checked') !== 'true') b.tabIndex = -1; });
    void cfg;
  }

  init();
})();
