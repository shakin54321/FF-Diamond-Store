(function () {
  'use strict';
  const { el, icon, fmt, config, reveal, reduced } = window.FF;

  /* =================== 3D card: pointer / touch / device-motion tilt =================== */
  function initCard() {
    const scene = document.getElementById('cardScene');
    const card = document.getElementById('card3d');
    if (!scene || !card || reduced) return;

    const MAX = 15;                       // max tilt in degrees
    let cx = 0; let cy = 0;              // current rotation
    let tx = 0; let ty = 0;              // target rotation
    let raf = 0; let visible = true; let touching = false;
    const clamp = (n, a, b) => Math.min(b, Math.max(a, n));

    function paint() {
      raf = 0;
      cx += (tx - cx) * 0.12; cy += (ty - cy) * 0.12;
      const nx = cy / MAX; const ny = -cx / MAX; // -1..1 in screen terms
      card.style.setProperty('--rx', `${cx.toFixed(2)}deg`);
      card.style.setProperty('--ry', `${cy.toFixed(2)}deg`);
      card.style.setProperty('--gx', `${(50 + nx * 42).toFixed(1)}%`);
      card.style.setProperty('--gy', `${(30 + ny * 42).toFixed(1)}%`);
      card.style.setProperty('--sheen', `${(nx * 38).toFixed(1)}%`);
      card.style.setProperty('--go', `${(0.55 + Math.min(1, Math.hypot(nx, ny)) * 0.45).toFixed(2)}`);
      if (Math.abs(tx - cx) > 0.02 || Math.abs(ty - cy) > 0.02) schedule();
    }
    function schedule() { if (!raf && visible) raf = requestAnimationFrame(paint); }
    function aim(nx, ny) { ty = clamp(nx, -1, 1) * MAX; tx = -clamp(ny, -1, 1) * MAX; schedule(); }
    function rest() { tx = 0; ty = 0; schedule(); }

    // Mouse: track across the whole hero so the card feels alive
    const hero = scene.closest('.hero') || scene;
    hero.addEventListener('pointermove', (e) => {
      if (e.pointerType !== 'mouse') return;
      const r = card.getBoundingClientRect();
      aim((e.clientX - (r.left + r.width / 2)) / (window.innerWidth * 0.45), (e.clientY - (r.top + r.height / 2)) / (window.innerHeight * 0.45));
    }, { passive: true });
    hero.addEventListener('pointerleave', (e) => { if (e.pointerType === 'mouse') rest(); });

    // Touch: drag on the card itself (vertical page scroll still works because of touch-action: pan-y)
    scene.addEventListener('pointerdown', (e) => { if (e.pointerType !== 'mouse') touching = true; });
    scene.addEventListener('pointermove', (e) => {
      if (e.pointerType === 'mouse' || !touching) return;
      const r = card.getBoundingClientRect();
      aim((e.clientX - (r.left + r.width / 2)) / (r.width * 0.6), (e.clientY - (r.top + r.height / 2)) / (r.height * 0.6));
    }, { passive: true });
    const endTouch = () => { touching = false; rest(); };
    scene.addEventListener('pointerup', endTouch);
    scene.addEventListener('pointercancel', endTouch);

    // Device motion (Android works directly; iOS asks permission on first tap)
    if ('DeviceOrientationEvent' in window && window.matchMedia('(pointer: coarse)').matches) {
      const onTilt = (e) => {
        if (touching || e.gamma === null || e.beta === null) return;
        aim(clamp(e.gamma, -25, 25) / 25, clamp(e.beta - 45, -25, 25) / 25);
      };
      const attach = () => window.addEventListener('deviceorientation', onTilt, { passive: true });
      if (typeof DeviceOrientationEvent.requestPermission === 'function') {
        scene.addEventListener('click', () => {
          DeviceOrientationEvent.requestPermission().then((s) => { if (s === 'granted') attach(); }).catch(() => {});
        }, { once: true });
      } else attach();
    }

    // Stop work when off-screen
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(([en]) => { visible = en.isIntersecting; if (visible) schedule(); }).observe(scene);
    }
  }

  /* =================== packages =================== */
  const grid = document.getElementById('pkgGrid');
  const state = { qty: new Map(), maxQty: 20 };

  function skeletons() {
    grid.replaceChildren(...Array.from({ length: 7 }, () => el('div', { class: 'pkg sk', 'aria-hidden': 'true' })));
  }

  function pkgCard(p) {
    const id = p.id;
    if (!state.qty.has(id)) state.qty.set(id, 1);
    const q = () => state.qty.get(id);
    const off = !p.available;

    const out = el('output', { class: 'qty-v', 'aria-live': 'polite' });
    const line1 = el('p'); const line2 = el('p');
    const total = el('strong');
    const minus = el('button', { type: 'button', class: 'qty-btn', 'aria-label': `Decrease quantity for ${fmt.int(p.diamonds)} diamonds` }, icon('minus'));
    const plus = el('button', { type: 'button', class: 'qty-btn', 'aria-label': `Increase quantity for ${fmt.int(p.diamonds)} diamonds` }, icon('plus'));

    function paint(bump) {
      const n = q();
      out.textContent = `${n}x`;
      line1.replaceChildren(`${fmt.int(p.diamonds)} Diamonds × ${n} = `, el('b', null, `${fmt.int(p.diamonds * n)} Diamonds`));
      line2.replaceChildren(`${fmt.taka(p.price)} × ${n} = `, el('b', null, fmt.taka(p.price * n)));
      total.textContent = fmt.taka(p.price * n);
      minus.disabled = off || n <= 1;
      plus.disabled = off || n >= state.maxQty;
      if (bump && !reduced) { total.classList.remove('bump'); void total.offsetWidth; total.classList.add('bump'); }
    }
    function step(d) {
      const n = Math.min(state.maxQty, Math.max(1, q() + d));
      if (n === q()) return;
      state.qty.set(id, n); paint(true);
    }
    minus.addEventListener('click', () => step(-1));
    plus.addEventListener('click', () => step(1));

    const buy = el('button', { type: 'button', class: 'btn btn-primary btn-block', disabled: off, onclick: () => openConfirm(p, q()) }, off ? 'Unavailable' : 'Buy Now');

    const card = el('article', { class: `pkg reveal${off ? ' is-off' : ''}`, 'aria-label': `${fmt.int(p.diamonds)} diamonds` },
      el('div', { class: 'pkg-top' },
        el('div', { class: 'pkg-gem' }, icon('gem', { size: 32 })),
        el('div', null, el('b', { class: 'pkg-d' }, fmt.int(p.diamonds)), el('span', null, 'Diamonds'))),
      el('div', { class: 'pkg-price' }, el('span', { class: 'cur' }, '৳'), el('span', { class: 'amt' }, fmt.int(p.price)), el('span', { class: 'per' }, 'per pack')),
      el('div', { class: 'qty', role: 'group', 'aria-label': `Quantity for ${fmt.int(p.diamonds)} diamonds` }, minus, out, plus),
      el('div', { class: 'calc' }, line1, line2),
      el('div', { class: 'pkg-total' }, el('span', null, 'Total'), total),
      buy);

    card.addEventListener('pointermove', (e) => {
      if (e.pointerType !== 'mouse') return;
      const r = card.getBoundingClientRect();
      card.style.setProperty('--mx', `${e.clientX - r.left}px`);
      card.style.setProperty('--my', `${e.clientY - r.top}px`);
    }, { passive: true });

    paint(false);
    return card;
  }

  async function loadPackages() {
    skeletons();
    try {
      const cfg = await config(true);
      state.maxQty = cfg.maxQty || 20;
      if (!cfg.packages.length) {
        grid.replaceChildren(el('div', { class: 'state-box' }, 'Packages are being updated. Please check back soon.'));
        return;
      }
      grid.replaceChildren(...cfg.packages.map(pkgCard));
      reveal(grid);
    } catch (err) {
      grid.replaceChildren(el('div', { class: 'state-box', role: 'alert' },
        el('p', null, err.message || 'We could not load the packages.'),
        el('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: loadPackages }, icon('refresh', { size: 16 }), 'Try again')));
    }
  }

  /* =================== confirmation modal =================== */
  const dlg = document.getElementById('confirmDlg');
  let pending = null;
  let opener = null;

  function openConfirm(p, qty) {
    pending = { packageId: p.id, quantity: qty };
    opener = document.activeElement;
    document.getElementById('dlgPkg').textContent = `${fmt.int(p.diamonds)} Diamonds`;
    document.getElementById('dlgQty').textContent = `${qty}x`;
    document.getElementById('dlgDia').textContent = `${fmt.int(p.diamonds * qty)} Diamonds`;
    document.getElementById('dlgTotal').textContent = fmt.taka(p.price * qty);
    document.body.classList.add('lock');
    dlg.showModal();
  }

  function closeConfirm() {
    if (!dlg.open) return;
    const done = () => { dlg.classList.remove('closing'); dlg.close(); };
    if (reduced) { done(); return; }
    dlg.classList.add('closing');
    dlg.addEventListener('animationend', done, { once: true });
  }

  dlg.addEventListener('close', () => {
    document.body.classList.remove('lock');
    if (opener && opener.focus) opener.focus({ preventScroll: true });
  });
  dlg.addEventListener('cancel', (e) => { e.preventDefault(); closeConfirm(); });         // Esc key
  dlg.addEventListener('click', (e) => { if (e.target === dlg) closeConfirm(); });        // backdrop click
  document.getElementById('dlgNo').addEventListener('click', closeConfirm);                // selection is kept
  document.getElementById('dlgYes').addEventListener('click', () => {
    if (!pending) return;
    // The selection travels in the URL (refresh-safe). The server re-reads price and availability itself.
    location.href = `/pay?pkg=${pending.packageId}&qty=${pending.quantity}`;
  });

  initCard();
  loadPackages();
})();
