// Runs before first paint: lets CSS hide .reveal elements only when JavaScript is available.
document.documentElement.classList.add('js');
