'use strict';
// Create or reset an admin account.
//   ADMIN_PASSWORD='a-long-passphrase' node scripts/set-admin.js [username]
// or run without ADMIN_PASSWORD to be prompted (input is hidden).
const path = require('node:path');
const readline = require('node:readline');

require('../lib/env').load(path.join(__dirname, '..', '.env'));
const { openDb, nowIso } = require('../lib/db');
const sec = require('../lib/security');

function promptHidden(question) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl._writeToOutput = (s) => { if (s.includes(question)) process.stdout.write(s); };
    rl.question(question, (a) => { rl.close(); process.stdout.write('\n'); resolve(a); });
  });
}

(async () => {
  const username = (process.argv[2] || process.env.ADMIN_USERNAME || 'admin').trim();
  let password = process.env.ADMIN_PASSWORD || '';
  if (!password) password = await promptHidden(`New password for "${username}" (min 12 chars): `);
  if (password.length < 12) { console.error('Password must be at least 12 characters.'); process.exit(1); }

  const db = openDb(path.resolve(__dirname, '..', process.env.DB_PATH || './data/store.db'));
  const hash = await sec.hashPassword(password);
  const existing = db.prepare('SELECT id FROM admins WHERE username = ?').get(username);
  if (existing) {
    db.prepare('UPDATE admins SET password_hash = ? WHERE id = ?').run(hash, existing.id);
    db.prepare('DELETE FROM sessions WHERE admin_id = ?').run(existing.id); // sign out everywhere
    console.log(`Password updated for "${username}". All sessions were signed out.`);
  } else {
    db.prepare('INSERT INTO admins (username, password_hash, created_at) VALUES (?, ?, ?)').run(username, hash, nowIso());
    console.log(`Admin "${username}" created.`);
  }
  db.close();
})();
